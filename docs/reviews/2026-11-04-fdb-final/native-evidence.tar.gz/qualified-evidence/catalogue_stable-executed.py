from pathlib import Path
from dataclasses import replace
import argparse,json,shutil,subprocess,sys,hashlib
r=Path(__file__).resolve().parent;repo=r.parent/'native-fdb';sys.path.insert(0,str(repo/'tools'))
from build_distribution import construct,geometry
from build_fdf_catalog import catalogue_payload
from fdfdecomp import decompile
from fdf_v1 import parse,serialize
from fdb_qualification_media import stage,audit
from test_z80pack_sysgen_install import session
from build_montezuma_extended_790k import build
from add_cpm_file_to_dmk import extract_raw
from run_trs80_command import DEFAULT_EMULATOR,key_args
from trs80gp_launch import run
p=argparse.ArgumentParser();p.add_argument('--target',required=True);a=p.parse_args();target=a.target
out=r/'fresh-acceptance'/('catalogue-stable-'+target);out.mkdir(parents=True)
root=r/'release-systems/work'/target;base=r/'fresh-baselines'/target;report=json.loads((base/'report.json').read_text());image=base/report['image']
stock=catalogue_payload();entries=parse(decompile(stock));baseformat=next(e for e in entries if 'KAYPRO' in e.description.upper());entry=replace(baseformat,ident='KAYNEW',description='Kaypro workbench test');single=serialize((entry,));text=decompile(single).encode()+b'\x1a'
fixtures=[('KAYPRO.FDB',single),('KAYPRO.FDF',text)]
if target=='trs80gp':fixtures += [('PREP.SUB',b'RSX UNLOAD ADM3A\r\nRSX UNLOAD M4SCRN\r\nRSX LIST\r\nTYPE READY.TXT\r\n\x1a'),('READY.TXT',b'CATALOGUE WORKSPACE READY\r\n\x1a')]
raw=construct(target,root,out,[],geometry(target,root),'');stage(target,raw,image,fixtures,out)
steps=[('FDB','Choice:'),('I','Source .FDB or .FDF:'),('KAYPRO.FDB','entire catalogue):'),('KAYNEW','1 added, 0 replaced.'),('D','Source: catalogue ID,'),('KAYNEW','Q or BREAK Return:'),('Q','Choice:'),('S','displayed default):'),('','Replace entire file (Y/N)?'),('Y','Catalogue saved and verified.'),('N','Choice:'),('I','Source .FDB or .FDF:'),('KAYPRO.FDF','entire catalogue):'),('KAYNEW','1 added, 0 replaced.'),('S','displayed default):'),('NEW.FDF','Create new file (Y/N)?'),('Y','Catalogue saved and verified.'),('Q','A0>')]
if target=='z80pack':
 disks=out/'disks';disks.mkdir();after=disks/'drivea.dsk';shutil.copy2(raw,after)
 session(r/'release-runtime/z80pack/cpmsim/cpmsim',disks,[((k+'\r').encode(),b'A0>_ ' if msg=='A0>' else msg.encode(),60) for k,msg in steps]+[(b'BYE /Y\r',b'System halted',30)],out/'trace.bin')
else:
 disk=out/'test.dmk';disk.write_bytes(build(raw.read_bytes()));cmd=[str(DEFAULT_EMULATOR),'-m4','-batch','-turbo','-ktx','-d0',str(disk),'-id','4000','-itime','15000','-iw','Type TYPE README.TXT for more','-id','4000']
 for k,msg in [('RSX UNLOAD ADM3A','A0>'),('RSX UNLOAD M4SCRN','A0>')]+steps:
  cmd+=key_args(k+'\r')+['-iw','A0> ' if msg=='A0>' else msg,'-id','3000' if msg=='A0>' else '200','-it']
 (out/'invocation.json').write_text(json.dumps(cmd,indent=2)+'\n');run(cmd,cwd=out,timeout=900,check=True)
 after=out/'after.raw';after.write_bytes(extract_raw(disk.read_bytes()))
for name,wanted in [('DISK.FDB',serialize((*entries,entry))),('KAYPRO.FDB',single),('KAYPRO.FDF',text),('NEW.FDF',None)]:
 dest=out/name;subprocess.run(['cpmcp','-T','raw','-f','bettercpm-default',str(after),'0:'+name,str(dest)],cwd=out,check=True,capture_output=True)
 if wanted is not None:assert dest.read_bytes()[:len(wanted)]==wanted,name
 else:assert serialize(parse(dest.read_bytes().split(b'\x1a')[0].decode()))==single
 audit(target,image,after,out,('DISK.FDB',))
(out/'result.json').write_text(json.dumps({'status':'PASS','target':target,'system_sha256':report['sha256'],'scope':'CurrentDISK.FDB I KAYPRO.FDB one entry, inspect, safeS; N I KAYPRO.FDF S NEW.FDF;108unrelated entries andbothsourcefiles preserved; alloriginalSystemfiles andreservedtracks audited'},indent=2)+'\n');print('PASS',target,'KAYPRO FDB/FDF catalogue workflow and N-I-S')
