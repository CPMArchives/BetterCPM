from pathlib import Path
import sys,json,shutil,hashlib
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r.parent/'native-fdb/tools'))
from add_cpm_file_to_dmk import extract_raw,add_file
from build_montezuma_extended_790k import build
from run_trs80_command import DEFAULT_EMULATOR,key_args
from trs80gp_launch import run
from test_sysgen_install import screen
from fdb_qualification_media import audit
out=r/'restore-focused';out.mkdir();base=r/'ui-native-final/baseline';report=json.loads((base/'report.json').read_text());original=base/report['image'];raw=extract_raw(original.read_bytes())
add_file(raw,'UNLOAD.SUB',b'CLS\r\nRSX UNLOAD ADM3A\r\nRSX UNLOAD M4SCRN\r\nRSX LIST\r\nTYPE FREE.TXT\r\n\x1a');add_file(raw,'FREE.TXT',b'WORKBENCH FREE READY 03\r\n\x1a')
disk=out/'restore.dmk';disk.write_bytes(build(raw));shutil.copy2(r/'fresh-baselines/trs80gp/diskdefs',out/'diskdefs')
cmd=[str(DEFAULT_EMULATOR),'-m4','-batch','-turbo','-ktx','-d0',str(disk),'-id','4000','-itime','15000','-iw','Type TYPE README.TXT for more','-id','4000']
def command(text,want,clear=False):
 global cmd
 if clear:cmd+=key_args('CLS\r')+['-id','300']
 cmd+=key_args(text+'\r')+['-iw',want,'-iw','A0> ','-id','300','-it']
command('RSX LIST','TPA available: 50K',True)
command('FDB','FDB: insufficient TPA or workspace.',True)
command('SUBMIT UNLOAD','WORKBENCH FREE READY 03')
for text,want in [('FDB','Choice:'),('D','Source: catalogue ID,'),('MMI012','Q or BREAK Return:'),('4','Q or BREAK Return:'),('Q','Choice:'),('Q','A0> ')]:cmd+=key_args(text+'\r')+['-iw',want,'-id','300','-it']
command('SUBMIT STARTUP','Type TYPE README.TXT for more')
command('RSX LIST','TPA available: 50K')
command('TYPE POST.TXT','UI RESTORED FILE READ PASS')
cmd+=['-ix'];(out/'invocation.json').write_text(json.dumps(cmd,indent=2)+'\n');run(cmd,cwd=out,check=True,timeout=1200)
frames=[screen(p) for p in sorted(out.glob('trs80-text*.bin'),key=lambda p:int(p.stem.rsplit('-',1)[1]))]
assert 'TPA available: 53K' in frames[2] and 'WORKBENCH FREE READY 03' in frames[2]
assert any('M4SCRN : BDOS 255' in f and 'ADM3A : BDOS 255' in f and 'TPA available: 50K' in f for f in frames[9:])
assert 'UI RESTORED FILE READ PASS' in frames[-1]
after=out/'after.raw';after.write_bytes(extract_raw(disk.read_bytes()));audit('trs80gp',original,after,out)
cold=out/'cold';cold.mkdir();cmd=[str(DEFAULT_EMULATOR),'-m4','-batch','-turbo','-ktx','-d0',str(disk),'-id','4000','-itime','15000','-iw','Type TYPE README.TXT for more','-iw','A0> ','-id','300']
cmd+=key_args('TYPE POST.TXT\r')+['-iw','UI RESTORED FILE READ PASS','-iw','A0> ','-id','300','-it']
cmd+=key_args('CLS\r')+['-id','300']+key_args('FDB\r')+['-iw','FDB: insufficient TPA or workspace.','-iw','A0> ','-id','300','-it','-ix'];(cold/'invocation.json').write_text(json.dumps(cmd,indent=2)+'\n');run(cmd,cwd=cold,check=True,timeout=400)
cf=[screen(p) for p in sorted(cold.glob('trs80-text*.bin'))];assert 'UI RESTORED FILE READ PASS' in cf[0] and 'FDB: insufficient TPA or workspace.' in cf[1]
after.write_bytes(extract_raw(disk.read_bytes()));audit('trs80gp',original,after,out)
(out/'result.json').write_text(json.dumps({'status':'PASS','fdb_sha256':hashlib.sha256((r/'ui-fixed/FDB.COM').read_bytes()).hexdigest(),'scope':'default50K safe refusal; queuedADM/M4unload53K;currentviewer/menu/Q;shippedSUBMITSTARTUP restoresM4thenADM50K;actualkeyboardfile-read;coldboot/defaultrefusal;all32originalSystemfiles/reservedtracks preserved','restore_method':'SUBMIT STARTUP, unmodified shipped script'},indent=2)+'\n');print('PASS focusedModel4 restore/file-read/coldboot/allfile preservation')
