from pathlib import Path
from dataclasses import replace
import sys,json,shutil,hashlib,subprocess
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r.parent/'native-fdb/tools'))
from add_cpm_file_to_dmk import extract_raw,add_file
from build_montezuma_extended_790k import build
from run_trs80_command import DEFAULT_EMULATOR,key_args
from trs80gp_launch import run
from test_sysgen_install import screen
from build_fdf_catalog import catalogue_payload
from fdfdecomp import decompile
from fdf_v1 import parse,serialize
from fdb_qualification_media import audit
out=r/'ui-native-final';out.mkdir();base=r/'fresh-baselines/trs80gp';report=json.loads((base/'report.json').read_text());raw=extract_raw((base/report['image']).read_bytes())
# Replace only the two workbench files on this private System copy.
# cpmtools permits explicit removal/replacement while all original source media stay intact.
shutil.copy2(base/'diskdefs',out/'diskdefs');rawpath=out/'base.raw';rawpath.write_bytes(raw)
for name in ('FDB.COM','FDBVIEW.OVL'):
 subprocess.run(['cpmrm','-T','raw','-f','bettercpm-default',str(rawpath),'0:'+name],cwd=out,check=True,capture_output=True)
 subprocess.run(['cpmcp','-T','raw','-f','bettercpm-default',str(rawpath),str(r/'ui-fixed'/name),'0:'+name],cwd=out,check=True,capture_output=True)
 for item in report['included']:
  if item['name']==name:item['sha256']=hashlib.sha256((r/'ui-fixed'/name).read_bytes()).hexdigest()
raw=bytearray(rawpath.read_bytes());entry=replace(parse(decompile(catalogue_payload()))[0],ident='WIDTH109');add_file(raw,'WIDTH.FDB',serialize((entry,)));add_file(raw,'POST.TXT',b'UI RESTORED FILE READ PASS\r\n\x1a')
disk=out/'test.dmk';disk.write_bytes(build(raw));private=out/'baseline';private.mkdir();(private/'report.json').write_text(json.dumps(report));shutil.copy2(disk,private/report['image'])
steps=[('RSX UNLOAD ADM3A','A0> '),('RSX UNLOAD M4SCRN','A0> '),('FDB','Choice:'),('I','Source .FDB or .FDF:'),('WIDTH.FDB','entire catalogue):'),('WIDTH109','Description (Enter=cancel):'),('ABCDEFGHIJKLMNOPQRSTUVWXYZ123456','1 added, 0 replaced.'),('Q','C Cancel:'),('D','A0> '),('FDB','Choice:'),('S','displayed default):'),('X'*33,'Invalid filename or ID.'),('D','Source: catalogue ID,'),('MMI012','Q or BREAK Return:'),('4','Q or BREAK Return:'),('Q','Choice:'),('Q','A0> ')]
cmd=[str(DEFAULT_EMULATOR),'-m4','-batch','-turbo','-ktx','-d0',str(disk),'-id','4000','-itime','15000','-iw','Type TYPE README.TXT for more','-id','4000']
for text,want in steps:
 if text=='FDB':cmd+=key_args('CLS\r')+['-id','300']
 cmd+=key_args(text+'\r')+['-iw',want,'-id','3000' if want=='A0> ' else '200','-it']
# Clear old prompts before each transient so a returned prompt is a real completion oracle.
for text in ('RSX LOAD M4SCRN','RSX LOAD ADM3A','RSX LIST','TYPE POST.TXT'):
 cmd+=key_args('CLS\r')+['-id','300']+key_args(text+'\r')
 if text=='RSX LIST':cmd+=['-iw','TPA available: 50K']
 if text=='TYPE POST.TXT':cmd+=['-iw','UI RESTORED FILE READ PASS']
 cmd+=['-iw','A0> ','-id','300','-it']
cmd+=['-ix'];(out/'invocation.json').write_text(json.dumps(cmd,indent=2));run(cmd,cwd=out,check=True,timeout=1200)
texts=[screen(p) for p in sorted(out.glob('trs80-text*.bin'),key=lambda p:int(p.stem.rsplit('-',1)[1]))];alltext='\n'.join(texts)
assert 'WIDTH109 duplicate. Description (Enter=cancel): ABCDEFGHIJKLMNOPQRSTUVWXYZ123456' in alltext
assert 'Invalid filename or ID.' in alltext and 'UI RESTORED FILE READ PASS' in alltext
assert any('M4SCRN : BDOS 255' in s and 'ADM3A : BDOS 255' in s and 'TPA available: 50K' in s for s in texts)
after=out/'after.raw';after.write_bytes(extract_raw(disk.read_bytes()));audit('trs80gp',private/report['image'],after,out)
cold=out/'cold';cold.mkdir();cmd=[str(DEFAULT_EMULATOR),'-m4','-batch','-turbo','-ktx','-d0',str(disk),'-id','4000','-itime','15000','-iw','Type TYPE README.TXT for more','-id','4000']
cmd+=key_args('TYPE POST.TXT\r')+['-iw','UI RESTORED FILE READ PASS','-id','3000','-it']
cmd+=key_args('FDB\r')+['-iw','FDB: insufficient TPA or workspace.','-id','3000','-it','-ix'];(cold/'invocation.json').write_text(json.dumps(cmd,indent=2));run(cmd,cwd=cold,check=True,timeout=400)
after.write_bytes(extract_raw(disk.read_bytes()));audit('trs80gp',private/report['image'],after,out)
coldtexts='\n'.join(screen(p) for p in cold.glob('trs80-text*.bin'))
assert 'UI RESTORED FILE READ PASS' in coldtexts and 'FDB: insufficient TPA or workspace.' in coldtexts
(out/'result.json').write_text(json.dumps({'status':'PASS','scope':'current UI-only FDBpair:32-char duplicate-description,overlongfilename newline,matchingviewer pages4,cleanexit,monitorrestoreorder,50Kstate,keyboardfile-read,coldboot/default50K safeFDBrefusal;alloriginalfiles+reservedtracks preserved','fdb_sha256':hashlib.sha256((r/'ui-fixed/FDB.COM').read_bytes()).hexdigest(),'pair_sha256':hashlib.sha256((r/'ui-fixed/FDBVIEW.OVL').read_bytes()).hexdigest()},indent=2)+'\n');print('PASS targeted nativeUI/newviewer and monitorrestore/coldboot')
