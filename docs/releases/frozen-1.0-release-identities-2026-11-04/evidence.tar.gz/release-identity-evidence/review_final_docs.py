from pathlib import Path
from urllib.parse import unquote
import json,re,hashlib,zipfile
r=Path(__file__).resolve().parent
fresh=r/'final-offline-reproduction/extracted';doc=next(fresh.glob('*Documentation*'));source=next(fresh.glob('*/source/BetterCPM'));packages=next((r/'manual-aligned-candidates/packages/candidates').iterdir())
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
for path in packages.glob('*.zip'):
 with zipfile.ZipFile(path) as z:
  base=next(n for n in z.namelist() if n.endswith('/RELEASE.json')).rsplit('/',1)[0]+'/'
  names={n[len(base):] for n in z.namelist()};matched=0
  for n in names:
   ref=n.removeprefix('source/BetterCPM/')
   if (ref.startswith('docs/') and (doc/ref).is_file()):assert z.read(base+n)==(doc/ref).read_bytes(),(path,n);matched+=1
  for n in ('LICENSE','COPYING','NOTICE','CC-BY-4.0.txt'):
   name='licenses/BetterCPM/'+n;assert z.read(base+name)==(doc/name).read_bytes()
  if 'System' in path.name or 'Utilities' in path.name:
   assert 'docs/user/FDB.md' in names
   assert 'docs/platform/MODEL4-SHIPPED-INSTALLATION.txt' in names
   assert 'docs/engineering/BCPM780-Installation-Qualification.md' in names
  rows.append({'package':path.name,'matching_manual_files':matched,'licenses_identical':True})
entries=['CONTENTS.md','docs/LICENSING.md','docs/releases/RELEASE-NOTES-1.0.md','docs/releases/DISTRIBUTION-BUILD.md','docs/releases/1.0-RELEASE-PACKAGES.md']+[str(p.relative_to(doc)) for p in (doc/'docs/user').glob('*.md') if p.name!='users_guide_backup.md']+['docs/platform/'+n for n in ('MODEL4-INSTALLATION.md','CPMSIM-INSTALLATION.md','FORMAT-SUPPORT-1.0.md')]
missing=[];external_source=[]
for n in entries:
 p=doc/n
 for no,line in enumerate(p.read_text().splitlines(),1):
  for dest in re.findall(r'\]\(([^)]+)\)',line):
   if dest.startswith(('#','http:','https:','mailto:')):continue
   target=(p.parent/unquote(dest.split('#')[0])).resolve()
   if not target.exists():
    rel=target.relative_to(doc.resolve())
    row=[n,no,dest]
    if (source/rel).exists():external_source.append(row)
    else:missing.append(row)
assert not missing,missing
# Generated editions remain deliberately excluded until separately reconciled.
assert not list(doc.rglob('*.docx')) and not list(doc.rglob('*.pdf'))
(r/'documentation-review.json').write_text(json.dumps({'status':'PASS','source_commit':json.loads((source/'SOURCE-IDENTITY.json').read_text())['source_commit'],'packages':rows,'unresolved_links':missing,'links_supplied_in_source_package':external_source,'generated_editions':'PDF/DOCX excluded','FDB_guide':'placement, companion lookup,53KiB requirement,unload/restore,conversion,safe replacement,named assignment,installation reviewed','historical_engineering_records':'milestone hashes/resources retained as dated evidence; final resources in final acceptance ledger','notices':'exact package notices and nested exclusions verified by package lock checker','freeze':'pending remaining native qualification; tagging/publication held'},indent=2)+'\n')
print('PASS manuals/licenses agree across6ZIPs; entrypoint links resolve in Documentation or Source; FDB/install guidance present')
