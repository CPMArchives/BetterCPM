from pathlib import Path
import subprocess,sys,json,os
w=Path(__file__).resolve().parent;r=w.parent/'licensing-review-20261103/review';env=dict(os.environ,PYTHONPYCACHEPREFIX='/private/tmp/bcpm780-pycache');rows=[]
cases=[('component', ['-m','unittest','discover','-s','tools','-p','test_component*.py']),('distribution',['-m','unittest','discover','-s','tools','-p','test_distribution.py']),('heading',['tools/test_release_identity_heading.py']),('versions',['tools/test_utility_versions.py']),('finalization',['tools/test_utility_finalization.py']),('presentation',['tools/test_release_presentation.py']),('crc',['tools/test_crc.py']),('md5sum',['tools/test_md5sum.py']),('compare',['tools/test_compare.py']),('patch',['tools/test_patch.py']),('search',['tools/test_search.py']),('pip-transfer',['tools/test_pip_transfer.py']),('config-command',['tools/test_config_command_line.py']),('dup-command',['tools/test_dup_command_line.py']),('codec-versions',['tools/test_codec_versions.py'])]
for name,args in cases:
 print(name,flush=True)
 try:
  with (w/(name+'-qualification.log')).open('wb') as log:q=subprocess.run([sys.executable,*args],cwd=r,env=dict(env,PYTHONPATH=str(r/'tools')),stdout=log,stderr=subprocess.STDOUT,timeout=300)
  rows.append({'name':name,'status':'PASS' if q.returncode==0 else 'FAIL','exit_code':q.returncode,'log':name+'-qualification.log'})
 except subprocess.TimeoutExpired:rows.append({'name':name,'status':'TIMEOUT'})
 (w/'host-qualification.json').write_text(json.dumps({'status':'PASS' if all(x['status']=='PASS' for x in rows) else 'FAIL','cases':rows},indent=2)+'\n')
