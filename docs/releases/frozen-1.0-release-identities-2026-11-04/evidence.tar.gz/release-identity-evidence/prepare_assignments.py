from pathlib import Path
import json

work = Path(__file__).resolve().parent
root = work.parent/'licensing-review-20261103/review'
regpath = root/'metadata/component-registry.json'
reg = json.loads(regpath.read_text())
audit = json.loads((work.parent/'release-freeze-20261104/development-identity-audit.json').read_text())
names = {n.split('.')[0] for n in audit['unique_names']} - {'R', 'W', 'MOUNT'}
names |= {'USER', 'CLS', 'MOVE'}
changes = []
for name in sorted(names):
    row = reg['components']['utility:'+name]
    old = row['revision']
    row['revision'] = old+1
    changes.append({'component':'utility:'+name, 'version':row['version'],
                    'old_revision':old, 'release_revision':old+1,
                    'reason':'One explicit release assignment for the changed qualified development executable.'})
for name, rev, desc in [('R',6,'Read Host Files into CP/M'), ('W',6,'Write CP/M Files to the Host'), ('MOUNT',3,'cpmsim Disk Mounting')]:
    key = 'utility:'+name
    assert key not in reg['components']
    reg['components'][key] = {'kind':'utility','version':'1.0','revision':rev,
        'api_version':None,'placement':'System, cpmsim only',
        'roots':['tools/build_qualified_cpmsim.py'],'builders':['tools/build_qualified_cpmsim.py'],
        'tracking':'initial','dependency_status':'selected pinned guest source, patches, generator and assembler',
        'display_format':'numeric','description':desc}
    reg['legacy_utility_order'].append(name)
    changes.append({'component':key,'version':'1.0','old_revision':rev-1,
                    'release_revision':rev,'reason':'Initial registry ownership continuing the existing guest development counter.'})
regpath.write_text(json.dumps(reg,indent=2)+'\n')
planpath = root/'metadata/component-inputs.json'
plans = json.loads(planpath.read_text())
common = ['tools/build_qualified_cpmsim.py','tools/guest_utility_identity.py',
          'tools/component_registry.py','tools/component_identity.py',
          'tools/component_inputs.py','tools/component_development.py',
          'third_party/z80pack/upstream.json','third_party/z80pack/offline-inputs.json']
common += [str(p.relative_to(root)) for p in sorted((root/'third_party/z80pack/patches').glob('*.patch'))]
for name in ('R','W','MOUNT'):
    plans['components']['utility:'+name] = {'status':'tracked','target':'z80pack',
        'targets':['z80pack'],'profile':'default','build_mode':'cross',
        'configuration':{'upstream_commit':'91fd28eb04e675c2127df88ed3f40675e15282e2',
                         'guest_assembler_flags':'-l -T -sn -p0 -8 -fb'},
        'files':common,'registry_fields':['display_format','description'],'identity_dependencies':[]}
for name in ('DIR','USER','CLS','VER','COPY','MOVE'):
    plans['components']['utility:'+name]['identity_dependencies'] = [
        'utility:'+x for x in ('RCP','DIR','USER','CLS','VER','COPY','MOVE')]
planpath.write_text(json.dumps(plans,indent=2)+'\n')
artpath = root/'metadata/component-artifacts.json'
art = json.loads(artpath.read_text())
for name in ('R','W','MOUNT'):
    art['components']['utility:'+name] = {'z80pack':['staged-host-tools/'+name+'.COM']}
artpath.write_text(json.dumps(art,indent=2)+'\n')
(work/'revision-assignments.json').write_text(json.dumps({
    'status':'explicit release-candidate assignments; qualification pending',
    'authorization':'User Go on identities/rebuild/replacement freeze; no tag/publication',
    'reference_source':'54c503652fa957798bf2d0d636f4172851195926',
    'changes':changes,
    'retained':'FDB 1.0 (001); independent subsystem/module/NOAH/third-party identities retained subject to byte comparison'
},indent=2)+'\n')
print('Prepared',len(changes),'explicit assignments; FDB remains 001')
