from pathlib import Path
import sys,json,hashlib
w=Path(__file__).resolve().parent;r=w.parent/'licensing-review-20261103/review';sys.path.insert(0,str(r/'tools'))
from fdb_qualification_media import audit
from add_cpm_file_to_dmk import extract_raw
from run_trs80_command import DEFAULT_EMULATOR
out=w/'restore-focused';base=w/'final-systems/trs80gp';rec=json.loads((base/'report.json').read_text());original=base/rec['image'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def screens(folder):return [bytes(x&127 for x in p.read_bytes()[:1920]).decode('ascii') for p in sorted(folder.glob('trs80-text*.bin'),key=lambda p:int(p.stem.rsplit('-',1)[1]))]
f=screens(out);assert len(f)==12
for i,text in [(0,'TPA available: 50K'),(1,'FDB: insufficient TPA or workspace.'),(2,'TPA available: 53K'),(2,'No RSXs loaded'),(3,'Choice:'),(4,'Source: catalogue ID,'),(5,'Format details/compare  Page 1'),(6,'Format details/compare  Page 4'),(7,'Choice:'),(9,'Type TYPE README.TXT for more'),(10,'M4SCRN : BDOS 255'),(10,'ADM3A : BDOS 255'),(10,'TPA available: 50K'),(11,'UI RESTORED FILE READ PASS')]:assert text in f[i],(i,text)
c=screens(out/'cold');assert len(c)==2 and 'UI RESTORED FILE READ PASS' in c[0] and 'FDB: insufficient TPA or workspace.' in c[1]
(out/'after.raw').write_bytes(extract_raw((out/'restore.dmk').read_bytes()));audit('trs80gp',original,out/'after.raw',out)
entry=next(i for i in rec['included'] if i['name']=='FDB.COM');binary=w/'final-systems/work/trs80gp'/entry['artifact'];assert sha(binary)==entry['sha256'];assert sha(original)==rec['sha256']
result={'status':'PASS','source_commit':rec['source']['revision'],'baseline_sha256':sha(original),'emulator_sha256':sha(DEFAULT_EMULATOR),'fdb_sha256':sha(binary),'captures':12,'cold_captures':2,'restore_method':'SUBMIT STARTUP, unmodified shipped script','scope':'default50K safe refusal; ADM3A thenM4SCRN unload to53K; interactive viewer pages1and4; menu/Q; shipped startup restores both providers50K; actualkeyboardfile read; coldboot/refusal; all32originalSystemfiles and20480reservedbytes preserved','receipt_correction':'Native workflow completed; original script failed only when recording a FDB hash from the wrong build directory. This verifier rechecks actual retained screens, media preservation and correct artifact hash; original failed log retained.'};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS independent retained-output verification of completed Model4 memory workflow')
