from pathlib import Path
import json,csv
w=Path(__file__).resolve().parent;r=w.parent/'licensing-review-20261103/review';assign={x['component'].split(':')[1] for x in json.loads((w/'revision-assignments.json').read_text())['changes']};delta=json.loads((w/'component-delta.json').read_text());locked={}
for row in csv.DictReader((r/'docs/engineering/evidence/2026-11-04-qualification-35c56a03/components.tsv').open(),delimiter='\t'):
 if row['class'] in ('system file','utilities file','companion file') and row['status']=='locked':locked[row['target'],row['component']]=row['sha256']
changes=[]
for row in delta['components']:
 key=row['target'],row['name']
 if key in locked and locked[key]!=row['sha256']:
  assert row['name'].split('.')[0] in assign,row
  assert locked[key]==row['old_sha256'],('unexpected divergence from old qualified lock',row)
  changes.append({**row,'old_locked_sha256':locked[key],'assigned_identity':next(x for x in json.loads((w/'revision-assignments.json').read_text())['changes'] if x['component'].split(':')[1]==row['name'].split('.')[0])})
(w/'promoted-component-pins.json').write_text(json.dumps({'status':'HASH EXPECTATIONS; execution qualification recorded separately, not a freeze','source_commit':'10160ab6876c5d773fc74a5b750ab21cc661e783','changes':changes},indent=2)+'\n')
s=(r/'tools/check_release_package_lock.py').read_text();anchor='\ndef read_records(raw, fmt):';addition='''
# Explicit successor expectations for exactly the identity-promoted utilities.
# Original lock is preserved; any undeclared change still fails.
promotion=json.loads((Path(__file__).resolve().parent/'promoted-component-pins.json').read_text())
for row in promotion['changes']:
    key=row['target'],row['name']
    assert locked[key]==row['old_locked_sha256']==row['old_sha256']
    locked[key]=row['sha256']
''';assert anchor in s;s=s.replace(anchor,addition+anchor);s=s.replace("if len(commits) != 1:","if commits != {promotion['source_commit']}:\n    failures.append('Promotion source identity differs')\nif len(commits) != 1:")
s=s.replace("'freeze': 'HOLD'","'freeze': 'PENDING independent runtime qualification and replacement freeze ledger'");s=s.replace("'remaining_gates': ['Final FDB/CONFIG/catalogue integration and placement', 'Catalogue binding/read and installation runtime acceptance', 'Source rebuild from the final exported ZIP', 'Final documentation sign-off', 'Affected regressions for changed media', 'Maintainer package freeze approval']","'scope': 'Static package validation with exact, explicit successor hashes for identity-promoted utilities. All unlisted historical locks remain enforced. Runtime qualification is separately required.', 'promoted_component_expectations': promotion['changes']")
(w/'check_replacement_packages.py').write_text(s);print('Explicit successor expectations',len(changes))
