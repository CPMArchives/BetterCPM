from pathlib import Path
import subprocess,sys,os
w=Path(__file__).resolve().parent
for i in range(3):
 print('chunk',i,flush=True)
 with (w/f'model4-query-chunk{i}.log').open('wb') as f:subprocess.run([sys.executable,str(w/'qualify_model4_queries.py'),'chunk'+str(i)],stdout=f,stderr=subprocess.STDOUT,check=True)
