"""Functional coverage for bodies relinked after identification text shrank."""
from pathlib import Path
import subprocess,sys,json,os,hashlib
w=Path(__file__).resolve().parent;r=w.parent/'licensing-review-20261103/review';env=dict(os.environ,PYTHONPYCACHEPREFIX='/private/tmp/bcpm780-pycache');rows=[]
for name,args in [('dasm',['tools/test_dasm.py']),('dsym',['tools/test_dsym.py']),('dlink',['tools/test_dlink.py']),('ted-frontend',['tools/test_ted_frontend.py','--output',w/'ted-functional.json']),('sq-functional',['tools/test_sq_com.py']),('usq-functional',['tools/test_usq_com.py']),('cr-functional',['tools/test_cr_com.py']),('lzh-functional',['tools/test_lzh_com.py'])]:
 print(name,flush=True)
 try:
  with (w/(name+'-relocation.log')).open('wb') as f:q=subprocess.run([sys.executable,*map(str,args)],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
  rows.append({'name':name,'status':'PASS' if q.returncode==0 else 'FAIL','exit_code':q.returncode,'log':name+'-relocation.log'})
 except subprocess.TimeoutExpired:rows.append({'name':name,'status':'TIMEOUT'})
 (w/'relocation-functional-checks.json').write_text(json.dumps({'status':'PASS' if all(x['status']=='PASS' for x in rows) else 'FAIL','purpose':'identification text changed addresses; compiled body functional regressions supplement query tests','cases':rows},indent=2)+'\n')
