        org 100h
        ld de,hello
        ld c,9
        call 5
        ld a,(80h)
        ld l,a
        ld h,0
        ld de,81h
        add hl,de
        ld (hl),36
        ld c,9
        call 5
        ld de,newline
        ld c,9
        call 5
        ld c,1
        call 5
        jp 0
hello: db 13,10,'NATIVE COMPLETE:','$'
newline: db 13,10,'$'
        end
