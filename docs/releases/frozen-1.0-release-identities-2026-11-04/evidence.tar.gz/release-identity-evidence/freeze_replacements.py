"""Seal only after every required exact-hash gate passes. Never overwrite a set."""
from pathlib import Path
import json,hashlib,zipfile,shutil,datetime,os,tarfile,io
w=Path(__file__).resolve().parent;r=w.parent/'licensing-review-20261103/review';base=w/'manual-aligned-candidates';packages=next((base/'packages/candidates').iterdir());source=packages.name;sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads((w/p).read_text())
gates=['relocation-functional-checks.json','host-qualification-final.json','final-offline-reproduction/result.json','documentation-review.json','final-package-audit-correct-path.json','release-identity-audit.json','core-carry-forward.json','xip-acceptance.json','offline-ROM-reproduction.json','native-cpmsim-queries/result.json','guest-system/result.json','native-cpmsim-install/result.json','restore-focused/result.json','install-model4/result.json']+[f'native-model4-queries-chunk{i}/result.json' for i in range(3)]
for p in gates:
 a=read(p);assert a['status'] in ('PASS','STATIC_CHECKS_PASS'),p
for p in ('final-offline-reproduction/result.json','documentation-review.json','release-identity-audit.json','xip-acceptance.json'):assert read(p)['source_commit']==source,p
static=read('final-package-audit-correct-path.json');assert static['source_commits']==[source] and not static['failures'];assets=[]
for p in sorted(packages.glob('*.zip')):
 with zipfile.ZipFile(p) as z:
  n=next(n for n in z.namelist() if n.endswith('/RELEASE.json'));rec=json.loads(z.read(n));assert rec['source_commit']==source
 assets.append({'package':rec['package'],'filename':p.name,'sha256':sha(p.read_bytes()),'size_bytes':p.stat().st_size})
assert len(assets)==6 and {x['package'] for x in assets}=={'source','documentation','system-cpmsim','system-model4','utilities-cpmsim','utilities-model4'}
assert {x['zip']:x['sha256'] for x in static['packages']}=={x['filename']:x['sha256'] for x in assets}
assert read('final-offline-reproduction/result.json')['source_zip_sha256']==next(x['sha256'] for x in assets if x['package']=='source')
systems={t:json.loads((base/'systems'/t/'report.json').read_text()) for t in ('z80pack','trs80gp')};cp=systems['z80pack']['sha256'];m4=systems['trs80gp']['sha256'];query=read('native-cpmsim-queries/result.json');assert query['images']['a']==cp and query['transient_cases']==129 and query['resident_version_cases']==9
assert read('guest-system/result.json')['system_sha256']==cp
for letter,pattern in [('b','BetterCPM-Utilities-z80pack*.dsk'),('c','BetterCPM-NOAH-z80pack*.dsk')]:
 assert query['images'][letter]==sha(next((base/'utilities').glob(pattern)).read_bytes())
assert query['emulator_sha256']==sha((base/'runtime/z80pack/cpmsim/cpmsim').read_bytes())
assert read('native-cpmsim-install/result.json')['baseline_sha256']==cp and read('native-cpmsim-install/result.json')['model4_baseline_sha256']==m4
allcases=[]
for i in range(3):
 q=read(f'native-model4-queries-chunk{i}/result.json');assert q['images']['a']==m4 and not q['failures'];assert all(c['status']=='PASS' for c in q['cases']);allcases+=q['cases']
 for letter,pattern in [('b','BetterCPM-Utilities-trs80gp*.dmk'),('c','BetterCPM-NOAH-trs80gp*.dmk')]:
  assert q['images'][letter]==sha(next((base/'utilities').glob(pattern)).read_bytes())
assert len(allcases)==126 and len({x['command'] for x in allcases})==126
install=read('install-model4/result.json');assert install['baseline_sha256']==m4 and install['installation_payload_differences']==[[7030,224,160]]
assert read('restore-focused/result.json')['baseline_sha256']==m4
assert read('restore-focused/result.json')['fdb_sha256']=='96e2cc0a6fcb79ad9fd23db1e321342077d0bcf485fe6153c8de509b85cdac45'
assert read('restore-focused/preservation.json')['reserved_bytes']==20480 and len(read('restore-focused/preservation.json')['original_files_preserved'])==32
assert sha((w/'test_mount_cleanup.py').read_bytes())==sha((r/'tools/test_cpmsim_mount_guest.py').read_bytes())
old=w.parent/'release-freeze-20261104/qualified-1.0-frozen';previous=json.loads((old/'FREEZE.json').read_text())
for a in previous['assets']:assert sha((old/'packages'/a['filename']).read_bytes())==a['sha256']
# Build a self-contained bounded evidence archive, excluding the large source
# reconstruction trees and six delivered ZIPs. Retain failed trials separately.
files={}
for path in w.iterdir():
 if path.is_file() and path.suffix in ('.py','.json','.log','.patch') and path.name not in ('CHECKPOINT.json',):files[path.name]=path.read_bytes()
for folder in ('native-cpmsim-queries','guest-system','native-cpmsim-install','restore-focused','install-model4','native-model4-queries-pilot','native-model4-queries-pilot2','native-model4-queries-chunk0','native-model4-queries-chunk1','native-model4-queries-chunk2'):
 for path in (w/folder).rglob('*'):
  if path.is_file():files[path.relative_to(w).as_posix()]=path.read_bytes()
for folder in ('final-offline-reproduction','manual-aligned-candidates'):
 for path in (w/folder).glob('*.log'):files[path.relative_to(w).as_posix()]=path.read_bytes()
files['final-offline-reproduction/result.json']=(w/'final-offline-reproduction/result.json').read_bytes()
files['manual-aligned-candidates/tested-media-continuity.json']=(base/'tested-media-continuity.json').read_bytes()
for path in (w/'xip-stock-fixture/rom').rglob('*.json'):files['xip-stock-fixture/rom/'+path.relative_to(w/'xip-stock-fixture/rom').as_posix()]=path.read_bytes()
for name in ('runtime/environment.json','runtime/guest-component-records.json','systems/z80pack/report.json','systems/trs80gp/report.json','utilities-inventory.json'):
 files['manual-aligned-candidates/'+name]=(base/name).read_bytes()
for path in (base/'utilities').glob('*.json'):files['manual-aligned-candidates/utilities/'+path.name]=path.read_bytes()
files['xip-emulator/environment.json']=(w/'xip-emulator/environment.json').read_bytes()
for name in ('rom-boot.bin','rom-boot.hex','rom-pack.bin','rom-image.bin'):
 files['xip-stock-fixture/rom/'+name]=(w/'xip-stock-fixture/rom'/name).read_bytes()
files['EVIDENCE-SHA256SUMS.txt']=''.join(f'{sha(data)}  {name}\n' for name,data in sorted(files.items())).encode()
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w:gz') as t:
 for name,data in sorted(files.items()):
  entry=tarfile.TarInfo('release-identity-evidence/'+name);entry.size=len(data);entry.mode=0o644;entry.mtime=0;t.addfile(entry,io.BytesIO(data))
evidence=buffer.getvalue();assert len(evidence)<100_000_000,len(evidence)
out=w/'qualified-1.0-frozen';out.mkdir(exist_ok=False);(out/'packages').mkdir()
(out/'evidence.tar.gz').write_bytes(evidence)
qualification={'schema':1,'status':'PASS','source_revision':source,'tested_media_sources':['93a434dda674c3479bec5579b1feec73831423d4','2e4edb69172e731fd1a2a720952c03c91bf00727'],'continuity':'all eight final media are byte-identical; later source changes are host-test and manual fixes; final exported Source and standalone System host kit reproduced exact media/runtime/guest hashes','gates':[{'path':p,'sha256':sha((w/p).read_bytes()),'status':read(p)['status']} for p in gates],'native_cpmsim_queries':129,'resident_cpmsim_queries':9,'native_model4_queries':126,'static_binary_instances_without_dev':108,'promoted_historical_lock_instances':76,'FDB_pair':'qualified PR608 pair retained at 1.0 (001)','RAM_core':'both reserved areas byte-identical to35c56a03; historical conformance accounting retained for matching core, not reassigned to changed utility hashes','XIP':'new exact ROM separately passed stock protected driver and seven controls; see xip-acceptance.json','original_freeze':'all six old54c50365 archives rehashed unchanged','evidence_archive':{'name':'evidence.tar.gz','sha256':sha(evidence),'bytes':len(evidence)},'excluded_claims':['physical hardware qualification','56K fullram promotion','new exhaustive whole-suite conformance run','tagging or publication'],'trial_policy':'retained failed/incomplete harness attempts are not passes; corrected final gates listed above control acceptance'}
(out/'QUALIFICATION.json').write_text(json.dumps(qualification,indent=2)+'\n')
freeze={'schema':1,'event':'QUALIFIED_REPLACEMENT_PACKAGE_SET_FROZEN','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'release_target':'BetterCP/M 1.0','source_revision':source,'review_PR':609,'review_url':'https://github.com/CPMArchives/BetterCPM/pull/609','review_state':'source/evidence PR requires maintainer review and merge; no automatic merge','source_revision_policy':'These are exact archives from the recorded source commit; later evidence-only commits do not relabel their source. Any changed archive requires a new qualification/freeze.','freeze_authorization':'User Go on release identities, replacement rebuild/qualification and replacement freeze; no tag or publication.','assets':assets,'supersedes_for_release_identity':previous['source_revision'],'old_reference_policy':'original54c50365 frozen set preserved byte-for-byte','release_identity_gate':{'status':'CLOSED for these exact archives','utility_display':'normal released numeric revisions, no -dev in executed shipped queries or108decoded binary instances','build_policy':'automatic selected-input comparison retained; no forced assigned-display override'},'qualification':{'path':'QUALIFICATION.json','sha256':sha((out/'QUALIFICATION.json').read_bytes())},'candidate_names':'exact candidate filenames and archive roots retained; freeze seals tested bytes; release publication remains separate','tagging':'NOT_AUTHORIZED_NOT_PERFORMED','publishing':'NOT_AUTHORIZED_NOT_PERFORMED'}
for a in assets:
 p=out/'packages'/a['filename'];shutil.copyfile(packages/a['filename'],p);assert sha(p.read_bytes())==a['sha256'];p.chmod(0o444)
(out/'FREEZE.json').write_text(json.dumps(freeze,indent=2)+'\n');(out/'SHA256SUMS.txt').write_text(''.join(a['sha256']+'  '+a['filename']+'\n' for a in assets));(out/'README.txt').write_text('BetterCP/M 1.0 replacement qualified set — FROZEN\n\nSource: '+source+'\nReview: https://github.com/CPMArchives/BetterCPM/pull/609\nSix immutable copies in packages/. See FREEZE.json and QUALIFICATION.json.\nDevelopment-identity gate CLOSED for these exact archives.\nOriginal54c50365 reference preserved. Candidate archive names retained.\nSource PR review/merge remains a maintainer action. No tags or publication.\n')
for p in out.iterdir():
 if p.is_file():p.chmod(0o444)
(out/'packages').chmod(0o555);out.chmod(0o555);print('FROZEN',source,len(assets),'archives;',len(evidence),'evidence bytes')
