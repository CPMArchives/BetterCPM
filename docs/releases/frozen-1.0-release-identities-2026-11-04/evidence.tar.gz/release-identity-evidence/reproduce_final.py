from pathlib import Path
import sys,json,zipfile,subprocess,os,hashlib
w=Path(__file__).resolve().parent;r=w.parent/'licensing-review-20261103/review';base=w/'manual-aligned-candidates';packages=next((base/'packages/candidates').iterdir());out=w/'final-offline-reproduction';out.mkdir(exist_ok=False);extract=out/'extracted';extract.mkdir();env=dict(os.environ,PYTHONPYCACHEPREFIX='/private/tmp/bcpm780-pycache');sha=lambda b:hashlib.sha256(b).hexdigest()
for name in ('BetterCPM-1.0-Source-candidate.zip','BetterCPM-1.0-System-cpmsim-candidate.zip'):
 with zipfile.ZipFile(packages/name) as z:
  for n in z.namelist():assert not Path(n).is_absolute() and '..' not in Path(n).parts
  z.extractall(extract)
source=extract/'BetterCPM-1.0-Source-candidate/source/BetterCPM';host=extract/'BetterCPM-1.0-System-cpmsim-candidate/host/BetterCPM';dep=next(source.parent.glob('dependencies/*.tar'));b=source/'build'
def run(root,args,label):
 print(label,flush=True)
 with (out/(label+'.log')).open('wb') as log:subprocess.run([sys.executable,*map(str,args)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
run(source,['tools/build_qualified_cpmsim.py','--source',dep,'--output',b/'cpmsim-runtime','--profile','runtime'],'source-runtime')
run(source,['tools/prepare_release_systems.py','--output',b/'candidate-systems','--simulator',b/'cpmsim-runtime/z80pack/cpmsim/cpmsim'],'source-systems')
run(source,['tools/build_utilities_disk.py','--build','--output',b/'candidate-utilities'],'source-utilities')
run(source,['tools/test_utilities_inventory.py','--artifacts',source,'--images',b/'candidate-utilities','--output',b/'utilities-inventory.json'],'source-inventory')
rows=[]
for target in ('z80pack','trs80gp'):
 rec=json.loads((base/'systems'/target/'report.json').read_text());rebuilt=b/'candidate-systems'/target
 for name in (rec['image'],'work-image'):
  data=(rebuilt/name).read_bytes();assert data==(base/'systems'/target/name).read_bytes(),(target,name);rows.append({'target':target,'name':name,'sha256':sha(data)})
 actual=json.loads((rebuilt/'report.json').read_text());assert {i['name']:i['sha256'] for i in actual['included']}=={i['name']:i['sha256'] for i in rec['included']}
for p in (base/'utilities').iterdir():
 if p.suffix in ('.dsk','.dmk'):
  data=(b/'candidate-utilities'/p.name).read_bytes();assert data==p.read_bytes(),p.name;rows.append({'name':p.name,'sha256':sha(data)})
old=json.loads((base/'runtime/environment.json').read_text());new=json.loads((b/'cpmsim-runtime/environment.json').read_text())
for group in ('executables','guest_utilities'):assert old[group]==new[group],group
run(host,['tools/build_qualified_cpmsim.py','--source',next((host/'dependencies').glob('*.tar')),'--output',host/'build/cpmsim-runtime','--profile','runtime'],'standalone-system-host')
standalone=json.loads((host/'build/cpmsim-runtime/environment.json').read_text())
for group in ('executables','guest_utilities'):assert old[group]==standalone[group],('standalone',group)
record={'status':'PASS','source_commit':json.loads((source/'SOURCE-IDENTITY.json').read_text())['source_commit'],'source_zip_sha256':sha((packages/'BetterCPM-1.0-Source-candidate.zip').read_bytes()),'system_zip_sha256':sha((packages/'BetterCPM-1.0-System-cpmsim-candidate.zip').read_bytes()),'media':rows,'all_system_components':'byte-identical','offline_runtime_executables':'byte-identical','guest_utilities':'byte-identical','standalone_System_host_kit':'offline build passed, same runtime and guest hashes','dependencies':'only extracted pinned source tar; no network acquisition'};(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print('PASS offline Source ZIP reconstruction, all eight images, runtime, guests and standalone System host kit')
