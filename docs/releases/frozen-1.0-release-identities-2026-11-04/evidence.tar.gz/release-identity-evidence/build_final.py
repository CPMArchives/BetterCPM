from pathlib import Path
import subprocess,sys,json,os
w=Path(__file__).resolve().parent;r=w.parent/'licensing-review-20261103/review';env=dict(os.environ,PYTHONPYCACHEPREFIX='/private/tmp/bcpm780-pycache');out=w/'replacement-candidates';out.mkdir(exist_ok=False)
dep=next((w.parent/'final-fdb-acceptance-20261104/review-candidates/fresh-extracted/BetterCPM-1.0-Source-candidate/source/dependencies').glob('*.tar'))
def run(args,label):
 print(label,flush=True)
 with (out/(label+'.log')).open('wb') as f:subprocess.run([sys.executable,*map(str,args)],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
run(['tools/build_qualified_cpmsim.py','--source',dep,'--output',out/'runtime','--profile','runtime'],'runtime')
run(['tools/prepare_release_systems.py','--output',out/'systems','--simulator',out/'runtime/z80pack/cpmsim/cpmsim'],'systems')
run(['tools/build_utilities_disk.py','--output',out/'utilities'],'utilities')
run(['tools/test_utilities_inventory.py','--artifacts',r,'--images',out/'utilities','--output',out/'utilities-inventory.json'],'inventory')
run(['tools/package_release_candidates.py','--cpmsim-system',out/'systems/z80pack','--model4-system',out/'systems/trs80gp','--utilities',out/'utilities','--inventory',out/'utilities-inventory.json','--upstream',Path.home()/'projects/git/z80pack','--runtime-manifest',out/'runtime/environment.json','--output',out/'packages'],'packages')
rows=[]
for t in ('z80pack','trs80gp'):
 before=json.loads((w/'final-systems'/t/'report.json').read_text());after=json.loads((out/'systems'/t/'report.json').read_text())
 assert before['sha256']==after['sha256'];assert before['work_image_sha256']==after['work_image_sha256'];rows.append({'target':t,'system_sha256':after['sha256'],'work_sha256':after['work_image_sha256'],'matches_tested_media':True})
for old in (w/'final-utilities').glob('*'):
 if old.suffix in ('.dsk','.dmk'):assert old.read_bytes()==(out/'utilities'/old.name).read_bytes(),old.name
(out/'tested-media-continuity.json').write_text(json.dumps({'status':'PASS','source_commit':after['source']['revision'],'prior_source':before['source']['revision'],'systems':rows,'all_four_utilities_images':'byte-identical','difference':'host test source only; no shipped executable change'},indent=2)+'\n');print('PASS eight media unchanged; six replacement archives assembled')
