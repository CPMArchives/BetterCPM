from pathlib import Path
import json,sys,os
work=Path(__file__).resolve().parent;root=work.parent/'licensing-review-20261103/review';sys.path.insert(0,str(root/'tools'))
from component_inputs import capture
assert os.environ.get('BETTERCPM_IDENTITY_STATE','auto')=='auto'
p=root/'metadata/component-baselines.json';before=p.read_bytes();(work/'component-baselines-before.json').write_bytes(before);catalog=json.loads(before);plans=json.loads((root/'metadata/component-inputs.json').read_text())['components'];updates=[]
selected={x['component'] for x in json.loads((work/'revision-assignments.json').read_text())['changes']}|{'utility:FDB','utility:NOAH'}
selected|={k for k in plans if k.startswith(('module:','subsystem:'))}
for owner in sorted(selected-{'utility:R','utility:W','utility:MOUNT'}):
 spec=plans[owner]
 for target in spec.get('targets',[spec['target']]):
  record=capture(owner,Path.home()/'bin/z80asm',root=root,target=target);key='|'.join((owner,target,'default','cross'));catalog['records'][key]=record;updates.append({'key':key,'identity':record['assigned_identity'],'fingerprint':record['fingerprint']})
p.write_text(json.dumps(catalog,indent=2,sort_keys=True)+'\n');(work/'baseline-assignments.json').write_text(json.dumps({'status':'explicit input-baseline assignments; artifact and execution acceptance pending','records':updates,'guest_records':'pending actual pinned guest assembler build'},indent=2)+'\n');print('Installed',len(updates),'explicit cross input baselines; no display override')
