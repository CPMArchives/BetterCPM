from pathlib import Path
import json,hashlib,re
w=Path(__file__).resolve().parent;p=w.parent
old=p/'final-fdb-acceptance-20261104/review-candidates';new=w
sha=lambda x:hashlib.sha256(x).hexdigest(); rows=[]
for target in ('z80pack','trs80gp'):
 a=json.loads((old/'release-systems'/target/'report.json').read_text());b=json.loads((new/'final-systems'/target/'report.json').read_text());aa={x['name']:x for x in a['included']};bb={x['name']:x for x in b['included']};assert aa.keys()==bb.keys()
 for name,r in bb.items():rows.append({'target':target,'class':'system','name':name,'old_sha256':aa[name]['sha256'],'sha256':r['sha256'],'changed':aa[name]['sha256']!=r['sha256']})
 for path in (new/'final-utilities').glob('*'+target+'*.json'):
  if not path.name.endswith(('.dmk.json','.dsk.json')):continue
  a=json.loads((old/'release-utilities'/path.name).read_text());b=json.loads(path.read_text());aa={x['name']:x for x in a['included']};bb={x['name']:x for x in b['included']};assert aa.keys()==bb.keys()
  for name,r in bb.items():rows.append({'target':target,'class':'utilities','name':name,'old_sha256':aa[name]['sha256'],'sha256':r['sha256'],'changed':aa[name]['sha256']!=r['sha256']})
for group in ('executables',):
 a=json.loads((old/'release-runtime/environment.json').read_text());b=json.loads((new/'final-runtime/environment.json').read_text());assert a[group]==b[group],group
report={'status':'DELTA_RECORDED; affected qualification pending','source':b['bettercpm_revision'],'runtime_executables':'unchanged','components':rows,'changed':[(x['target'],x['name']) for x in rows if x['changed']]}
(w/'component-delta.json').write_text(json.dumps(report,indent=2)+'\n');print('changed',len(report['changed']),report['changed']);print('retained FDB',[(x['target'],x['name'],x['changed']) for x in rows if x['name'].startswith(('FDB','M4SCRN','NOAH'))])
