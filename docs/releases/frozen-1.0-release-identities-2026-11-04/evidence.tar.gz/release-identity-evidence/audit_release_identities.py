from pathlib import Path
import json,re,hashlib,sys,ast
w=Path(__file__).resolve().parent;r=w.parent/'licensing-review-20261103/review';sys.path.insert(0,str(r/'tools'))
from fdf_format import select_fdf
from convert_fdf_image import dmk_to_raw
from add_cpm_file_to_dmk import extract_raw
from component_registry import load
node=next(n for n in ast.parse((r/'tools/check_release_package_lock.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='read_records');ns={};exec(compile(ast.Module(body=[node],type_ignores=[]),'<record reader>','exec'),ns);read=ns['read_records'];sha=lambda x:hashlib.sha256(x).hexdigest();base=w/'manual-aligned-candidates';registry=load()['components'];rows=[];fail=[]
for target in ('z80pack','trs80gp'):
 s=base/'systems'/target;receipt=json.loads((s/'report.json').read_text());data=(s/receipt['image']).read_bytes();raw=extract_raw(data) if target=='trs80gp' else data
 # cpmtools-independent record reader uses the logical-track System convention.
 if target=='trs80gp':
  from dataclasses import replace
  fmt=replace(select_fdf(r/'metadata/DISK.FDF','MMI008'),off=4,dsm=389,sector_ids=tuple(range(1,11)))
 else:fmt=select_fdf(r/'metadata/DISK.FDF','MMF017')
 members=read(raw,fmt)
 groups=[(receipt,members)]
 for p in (base/'utilities').glob('*'+target+'*.json'):
  if not p.name.endswith(('.dmk.json','.dsk.json')):continue
  rec=json.loads(p.read_text());payload=p.with_suffix('').read_bytes();f=select_fdf(r/'metadata/DISK.FDF','MMI008' if target=='trs80gp' else 'MMF017');rawu=dmk_to_raw(payload,f) if target=='trs80gp' else payload;groups.append((rec,read(rawu,f)))
 for rec,member in groups:
  for item in rec['included']:
   n=item['name'];payload=member[item.get('user',0),n][:item['bytes']];assert sha(payload)==item['sha256'],n
   if n.endswith(('.COM','.CPX','.RSX','.OVL')):
    dev=re.findall(rb'\b[A-Z][A-Z0-9]* [0-9]+\.[0-9]+ \([0-9]+-dev\)',payload)
    if dev:fail.append([target,n,[x.decode() for x in dev]])
    rows.append({'target':target,'name':n,'sha256':sha(payload),'development_identity_strings':[x.decode() for x in dev]})
result={'status':'FAIL' if fail else 'PASS','source_commit':receipt['source']['revision'],'scope':'actual file bytes independently decoded from all six nonblank System/Utilities images; development numeric component identification strings','files':rows,'failures':fail};(w/'release-identity-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status'],len(rows),'binary instances;',fail)
