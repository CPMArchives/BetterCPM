from pathlib import Path
import sys,json,shutil,hashlib
w=Path(__file__).resolve().parent;r=w.parent/'licensing-review-20261103/review';sys.path.insert(0,str(r/'tools'))
from test_z80pack_sysgen_install import session
from component_registry import utility_identities
from component_identity import title
out=w/'native-cpmsim-queries';out.mkdir(exist_ok=False);d=out/'disks';d.mkdir();s=w/'final-systems/z80pack';u=w/'final-utilities';rec=json.loads((s/'report.json').read_text());paths={'a':s/rec['image'],'b':next(u.glob('BetterCPM-Utilities-z80pack*.dsk')),'c':next(u.glob('BetterCPM-NOAH-z80pack*.dsk')),'d':s/'work-image'};sha=lambda x:hashlib.sha256(x).hexdigest();images={k:sha(p.read_bytes()) for k,p in paths.items()}
for k,p in paths.items():shutil.copy2(p,d/('drive'+k+'.dsk'))
identities=utility_identities();cases=[]
for letter in 'abc':
 report=rec if letter=='a' else json.loads(Path(str(paths[letter])+'.json').read_text())
 for row in report['included']:
  n=row['name']
  if not n.endswith('.COM') or n[:-4] not in identities:continue
  name=n[:-4];v,rev=identities[name];expected=title(name,v,rev).encode()
  for switch in ('/VER','/H','/HELP'):
   cases.append({'command':letter.upper()+':'+name+' '+switch,'expected':expected.decode(),'name':name,'switch':switch,'sha256':row['sha256']})
steps=[]
for case in cases:steps.extend([(case['command'].encode()+b'\r',case['expected'].encode(),30),(b'',b'A0>_ ',30)])
for name in ('DIR','ERA','TYPE','REN','CLS','USER','VER','COPY','MOVE'):
 v,rev=identities['RCP'];expected=title(name,v,rev).encode();steps.extend([((name+' /VER').encode()+b'\r',expected,30),(b'',b'A0>_ ',30)])
steps.extend([(b'VER\r',b'BetterCP/M 1.0\r\n',30),(b'',b'A0>_ ',30),(b'RSX LIST\r',b'TPA available: 53K',30),(b'',b'A0>_ ',30)])
(out/'cases.json').write_text(json.dumps(cases,indent=2)+'\n');text=session(w/'final-runtime/z80pack/cpmsim/cpmsim',d,steps,out/'transcript.bin');assert b'-dev)' not in text
for letter in 'bc':assert sha((d/('drive'+letter+'.dsk')).read_bytes())==images[letter]
for k,p in paths.items():assert sha(p.read_bytes())==images[k]
(out/'result.json').write_text(json.dumps({'status':'PASS','source_commit':rec['source']['revision'],'images':images,'emulator_sha256':sha((w/'final-runtime/z80pack/cpmsim/cpmsim').read_bytes()),'transient_cases':len(cases),'resident_version_cases':9,'normal_VER':'BetterCP/M 1.0','TPA':'53K','no_development_identities':True,'transcript_sha256':sha(text)},indent=2)+'\n');print('PASS',len(cases),'transient queries plus 9 resident queries, VER and53K')
