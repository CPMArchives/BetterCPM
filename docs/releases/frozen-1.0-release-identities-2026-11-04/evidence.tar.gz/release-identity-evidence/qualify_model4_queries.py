from pathlib import Path
import sys,json,shutil,hashlib,subprocess
w=Path(__file__).resolve().parent;r=w.parent/'licensing-review-20261103/review';sys.path.insert(0,str(r/'tools'))
from component_registry import utility_identities
from component_identity import title
from add_cpm_file_to_dmk import extract_raw,add_file,FILESYSTEM_FIRST_SECTOR,SECTOR_SIZE,DIRECTORY_ENTRIES
from build_montezuma_extended_790k import build
from run_trs80_command import DEFAULT_EMULATOR,key_args
from trs80gp_launch import run
sha=lambda b:hashlib.sha256(b).hexdigest()
phase=sys.argv[1] if len(sys.argv)>1 else 'full';out=w/('native-model4-queries-'+phase);out.mkdir(exist_ok=False)
s=w/'final-systems/trs80gp';u=w/'final-utilities';rec=json.loads((s/'report.json').read_text());original=s/rec['image'];paths={'a':original,'b':next(u.glob('BetterCPM-Utilities-trs80gp*.dmk')),'c':next(u.glob('BetterCPM-NOAH-trs80gp*.dmk'))};hashes={k:sha(v.read_bytes()) for k,v in paths.items()};ids=utility_identities();cases=[]
for letter in 'abc':
 report=rec if letter=='a' else json.loads(Path(str(paths[letter])+'.json').read_text())
 for row in report['included']:
  name=row['name']
  if not name.endswith('.COM') or name[:-4] not in ids:continue
  n=name[:-4];v,rev=ids[n]
  for switch in ('/VER','/H','/HELP'):cases.append({'command':letter.upper()+':'+n+' '+switch,'expected':title(n,v,rev) if switch=='/VER' else 'Usage:','component':n,'switch':switch,'sha256':row['sha256']})
for name in ('DIR','ERA','TYPE','REN','CLS','USER','VER','COPY','MOVE'):
 v,rev=ids['RCP'];cases.append({'command':name+' /VER','expected':title(name,v,rev),'component':'RCP','switch':'/VER'})
if phase=='pilot':cases=cases[:3]
if phase.startswith('chunk'):
 offset=int(phase[5:])*42;cases=cases[offset:offset+42]
asm='''        org 100h
        ld de,hello
        ld c,9
        call 5
        ld a,(80h)
        ld l,a
        ld h,0
        ld de,81h
        add hl,de
        ld (hl),36
        ld c,9
        call 5
        ld de,newline
        ld c,9
        call 5
        ld c,1
        call 5
        jp 0
hello: db 13,10,'NATIVE COMPLETE:','$'
newline: db 13,10,'$'
        end
''';(out/'marker.asm').write_text(asm);subprocess.run([str(Path.home()/'bin/z80asm'),'-fb','-o'+str(out/'MARK.COM'),str(out/'marker.asm')],check=True)
raw=extract_raw(original.read_bytes());directory=FILESYSTEM_FIRST_SECTOR*SECTOR_SIZE
for i in range(DIRECTORY_ENTRIES):
 at=directory+i*32
 if raw[at]==0 and raw[at+1:at+12]==b'STARTUP SUB':raw[at]=0xe5
add_file(raw,'MARK.COM',(out/'MARK.COM').read_bytes());script=['RSX LOAD M4SCRN','RSX LOAD ADM3A']
for i,case in enumerate(cases):script+=['CLS',case['command'],f'MARK CASE{i:03d}DONE']
add_file(raw,'STARTUP.SUB',('\r\n'.join(script)+'\r\n\x1a').encode());(out/'STARTUP.SUB').write_text('\r\n'.join(script)+'\r\n');disk=out/'a.dmk';disk.write_bytes(build(raw));
for k in 'bc':shutil.copy2(paths[k],out/(k+'.dmk'))
cmd=[str(DEFAULT_EMULATOR),'-m4','-batch','-turbo','-ktx','-d0',str(disk),'-d1',str(out/'b.dmk'),'-d2',str(out/'c.dmk'),'-id','4000','-itime','60000']
for i,case in enumerate(cases):cmd+=['-iw',f'CASE{i:03d}DONE','-id','400','-it']+key_args('\r',delay=12)
cmd+=['-ix'];(out/'invocation.json').write_text(json.dumps(cmd,indent=2)+'\n');(out/'cases.json').write_text(json.dumps(cases,indent=2)+'\n');run(cmd,cwd=out,timeout=1200)
captures=sorted(out.glob('trs80-text-*'),key=lambda p:int(p.stem.rsplit('-',1)[1]));assert len(captures)==len(cases),(len(captures),len(cases))
fail=[]
for i,(case,path) in enumerate(zip(cases,captures)):
 data=bytes(x&127 for x in path.read_bytes()[:1920]);text='\n'.join(data[j:j+80].decode('ascii',errors='replace').rstrip() for j in range(0,1920,80));(out/(f'screen-{i:03d}.txt')).write_text(text)
 case['status']='PASS' if case['expected'] in text and '-dev)' not in text and 'NATIVE COMPLETE:' in text and f'CASE{i:03d}DONE' in text else 'FAIL'
 if case['status']=='FAIL':fail.append({'case':i,**case})
for k in 'bc':assert sha((out/(k+'.dmk')).read_bytes())==hashes[k]
for k,path in paths.items():assert sha(path.read_bytes())==hashes[k]
result={'status':'FAIL' if fail else 'PASS','source_commit':rec['source']['revision'],'emulator_sha256':sha(DEFAULT_EMULATOR.read_bytes()),'images':hashes,'cases':cases,'failures':fail,'harness':'private STARTUP.SUB, serial shipped commands, private marker waits for consumed keyboard acknowledgment before continuing; original images unchanged'};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status'],len(cases),'Model4 native queries');assert not fail,fail
