from pathlib import Path
import shutil,subprocess,sys,json,os,hashlib
w=Path(__file__).resolve().parent;s=w/'manual-aligned-candidates/systems/work/z80pack';root=w/'xip-source';root.mkdir(exist_ok=False)
for name in ('src','tools','metadata','third_party','build'):shutil.copytree(s/name,root/name)
exclude=root/'fixture-excluded';exclude.mkdir();removed=[]
for name in ('FDB.COM',):
 p=root/'build/utilities'/name
 if p.exists():shutil.move(p,exclude/name);removed.append(name)
(root/'SOURCE-IDENTITY.json').write_text(json.dumps({'source_commit':'30b24a0'+subprocess.check_output(['git','-C',str(w.parent/'licensing-review-20261103/review'),'rev-parse','HEAD']).decode().strip()[7:]}))
(w/'xip-fixture-selection.json').write_text(json.dumps({'scope':'stock protected-XIP qualification fixture, not release disk membership','excluded_from_development_fixture':removed,'reason':'full development inventory overfills 332K; FDB exercised on shipped RAM System images, not used by stock ROM driver','production_source':'unchanged copy of exact release snapshot'},indent=2)+'\n')
env=dict(os.environ,PYTHONPYCACHEPREFIX='/private/tmp/bcpm780-pycache')
with (w/'xip-narrow-fixture.log').open('wb') as f:subprocess.run([sys.executable,str(root/'tools/build_z80pack_image.py'),'--output',str(w/'xip-narrow-fixture'),'--simulator',str(w/'xip-emulator/z80pack/cpmsim/cpmsim')],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
with (w/'xip-narrow-qualification.log').open('wb') as f:subprocess.run([sys.executable,str(root/'tools/test_z80pack_rom_xip.py'),'--image-dir',str(w/'xip-narrow-fixture'),'--simulator',str(w/'xip-emulator/z80pack/cpmsim/cpmsim')],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
print('PASS new stock protected-XIP qualification')
