import hashlib,json,os,pty,select,shutil,subprocess,sys,time,zipfile
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools'))
from test_altair_system import Terminal
root=Path.cwd();package=root/'build/releases/BetterCPM-1.3-Altair-cb561f7';out=root/'build/altair-package-checks-02'
out.mkdir(exist_ok=False)
for n,folder in [('BetterCPM-1.3-Altair.zip','media'),('BetterCPM-1.3-Altair-Source.zip','source')]:
 with zipfile.ZipFile(package/n) as z:
  assert z.testzip() is None;z.extractall(out/folder)
media=out/'media/BetterCPM-1.3-Altair';source=out/'source/BetterCPM-source'
sys.path.insert(0,str(source/'tools'))
manifest=json.loads((source/'SOURCE-FILES.json').read_text())
for n,wanted in manifest.items():assert hashlib.sha256((source/n).read_bytes()).hexdigest()==wanted,n
print('Exported source manifest verified:',len(manifest),'files',flush=True)
def launch(c='Utilities-1',d='Utilities-2'):
 t=Terminal.__new__(Terminal);t.master,slave=pty.openpty();t.work=out
 t.command=[sys.executable,str(media/'Run-Altair.py'),'--session',str(out/'Session'),'--c',c,'--d',d]
 t.process=subprocess.Popen(t.command,cwd=media,stdin=slave,stdout=slave,stderr=slave);os.close(slave)
 t.data=bytearray();t.cursor=0;t.prompt();return t
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
masters={p.name:sha(p) for p in (media/'Media').glob('*.dsk')}
t=launch()
try:
 t.send('STAT MEM','Maximum loadable COM: 57344 bytes');t.send('PIP B:HELLO.TXT=A:README.TXT')
 t.cursor=len(t.data);os.write(t.master,b'BYE /Y\r')
 deadline=time.monotonic()+5
 while t.process.poll() is None and time.monotonic()<deadline:
  if select.select([t.master],[],[],0.1)[0]:
   try:t.data.extend(os.read(t.master,65536))
   except OSError:break
 assert t.process.poll()==0,t.data.decode('latin1')[-1500:]
finally:t.close();shutil.copy2(out/'transcript.txt',out/'first-launch.txt')
saved=sha(out/'Session/disks/driveb.dsk');binary=sha(media/'Host/build/altair/altairsim/altairsim')
t=launch('Utilities-2','Utilities-3')
try:
 t.send('DIR B:','HELLO');t.send('VER','BetterCP/M 1.3')
 t.cursor=len(t.data);os.write(t.master,b'BYE /Y\r')
 deadline=time.monotonic()+5
 while t.process.poll() is None and time.monotonic()<deadline:
  if select.select([t.master],[],[],0.1)[0]:
   try:t.data.extend(os.read(t.master,65536))
   except OSError:break
 assert t.process.poll()==0,t.data.decode('latin1')[-1500:]
finally:t.close();shutil.copy2(out/'transcript.txt',out/'resumed-launch.txt')
assert saved==sha(out/'Session/disks/driveb.dsk')
assert binary==sha(media/'Host/build/altair/altairsim/altairsim')
assert masters=={p.name:sha(p) for p in (media/'Media').glob('*.dsk')}
print('Packaged launcher: offline first build, preserved A/B, explicit C/D swaps and immutable masters PASS',flush=True)
with (out/'source-rebuild.log').open('w') as log:
 subprocess.run([sys.executable,'-B',str(source/'tools/build_altair.py'),'--release','--work',str(out/'rebuild')],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
rebuilt=out/'rebuild/profiles/altair-fullram/altair/build/altair/release'
for n,wanted in masters.items():
 if n.endswith('-Work.dsk'):continue
 assert sha(rebuilt/n)==wanted,n
result={'status':'PASS','source_commit':'cb561f759f81e215a0fe57256398c648dc0a23fc','media_sha256':sha(package/'BetterCPM-1.3-Altair.zip'),'source_sha256':sha(package/'BetterCPM-1.3-Altair-Source.zip'),'source_manifest_files':len(manifest),'checks':['archive CRC and source manifest','offline packaged first-launch emulator build','writable session persistence','Utilities mount selection','unchanged master images','complete reconstruction from exported source ZIP: all four images identical']}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS: exact downloaded package and source reconstruction',flush=True)
