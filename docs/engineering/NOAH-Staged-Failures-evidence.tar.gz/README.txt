NOAH revision 10 staged-operation failure qualification, 2026-10-25.
native/: completed native resident/controller builds and real disk-full runtime
campaigns on both platforms. Four unchanged codec products were verified before
reuse; their original native products and build receipts are under reused/.
Self-contained six-module native sources, layout and exact cross products are
under native/cross/. NFILL is a bounded qualification-only helper; the disk is
prefilled on the host with four blocks reserved for startup/SUBMIT, then filled
natively. R retries a failed member; S advances to an empty member without data
allocation. Exact output, input preservation, filesystem and post-exit checks pass.
host/: 19 focused staged-failure transactions plus existing regression suites.
source/: changed maintained implementation, metadata and build/test inputs.
Disk images and assembler listings are excluded; file products, complete console,
invocation/execution, filesystem and preparation receipts remain with hashes.
Earlier development campaigns are excluded; all accepted products correspond to
the final source. No full NOAH or Utilities release acceptance is claimed.
