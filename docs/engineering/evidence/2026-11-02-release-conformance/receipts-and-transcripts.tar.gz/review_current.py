import json,hashlib
from pathlib import Path
r=Path.cwd();o=r/'build/rc564-conformance'
def ev(p):
 p=p.resolve();return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def one(folder):
 x=list((o/folder).glob('*/result.json'));assert len(x)==1;return x[0]
def group(cards,status,scope,paths):
 return {'cards':cards,'status':status,'scope':scope,'evidence':[ev(p) for p in paths],
 'platforms':{'cpmsim':scope,'model4':'Fresh native execution pending Terminal batch; controlled instruction evidence is not native execution.'}}
old=json.load(open('docs/releases/SYSTEM-VALIDATION-FINAL-V052-EVIDENCE.json'))['reviewed_groups']['groups']
g=[]
paths=[
 [o/'documentary/result.json'],
 [o/'documentary/result.json',o/'test_unified_bdos.log'],
 [o/'test_ccp.log'],
 [one('returns'),one('full-tpa')],
 [one('full-tpa')],
 [o/'batch/result.json'],
 [o/'directory-full/result.json'],
 [o/'character-accounting/result.json'],
 [o/'failure-accounting/result.json'],
 [o/'failure-accounting/result.json'],
 [o/'ccp-profile/result.json',r/'docs/engineering/CCP Fixed A0 Lookup.md'],
 [o/'ccp-profile/result.json'],
 [o/'media-change-final/result.json'],
 [o/'test_bios.log',o/'test_unified_bdos.log'],
 [o/'bios-retry-final.log'],
 [one('faults-final'),o/'directory-full/result.json'],
 [r/'docs/engineering/BDOS-BAD-SECTOR-RECOVERY.md']]
assert len(old)==len(paths)
for i,(row,source) in enumerate(zip(old,paths)):
 cards=[n for n in row['cards'] if n!='0020']
 # Physical native claims in old descriptions do not transfer to this run.
 scope=row['scope'] if i not in (6,12,15) else [
  'Fresh actual cpmsim Functions 21/34 directory-full comparison with DRI; no native Model 4 claim.',
  'Fresh cpmsim logged-media replacement and explicit-reset witnesses; no native claim.',
  'Fresh cpmsim operator-recovery and directory-full witnesses; no native claim.'
 ][(6,12,15).index(i)]
 g.append(group(cards,row['status'],scope,source))
g.append(group(['0020'],'PROFILE_DIFFERENCE','Current CCP preserves mixed-case command-tail text, while the default FCB is uppercase. Pinned generic uppercase-tail oracle fails; observed profile only, not generic conformance PASS.',[o/'ccp-profile/result.json',o/'ccp-accounting/transcript.bin']))
base=json.load(open('build/rc564-systems/z80pack/report.json'))
(o/'reviewed.json').write_text(json.dumps({'baseline_sha256':base['sha256'],'groups':g},indent=2)+'\n')
