import subprocess,sys,json
from pathlib import Path
r=Path.cwd();o=r/'build/rc564-conformance';base=r/'build/rc564-systems/z80pack';suite=r/'build/rc564-conformance-suite';sim=r/'build/rc564-runtime/z80pack/cpmsim/cpmsim';source=r/'build/rc564-systems/work/z80pack'
common=['--baseline',str(base),'--suite',str(suite),'--diskdefs',str(base/'diskdefs'),'--simulator',str(sim)]
jobs=[('returns','run_validation_ccp_returns.py',common),('full-tpa','run_validation_ccp_returns.py',common+['--full-tpa']),('faults','run_validation_faults.py',common),('documentary','run_validation_documentary_probes.py',['--build-root',str(source)]),('batch','run_validation_cpmsim_batch.py',['--baseline',str(base),'--build-root',str(source),'--simulator',str(sim)]),('media-change','run_validation_cpmsim_media_change.py',['--baseline',str(base),'--simulator',str(sim)])]
results={}
for name,tool,args in jobs:
 print('Running',name,flush=True)
 with (o/(name+'.log')).open('w') as log:p=subprocess.run([sys.executable,'tools/'+tool]+args+['--output',str(o/name)],stdout=log,stderr=subprocess.STDOUT)
 results[name]={'exit_code':p.returncode};(o/'additional-results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,p.returncode,flush=True)
for name in ('test_ccp','test_bios','test_bios_retry','test_unified_bdos'):
 print('Running',name,flush=True)
 with (o/(name+'.log')).open('w') as log:p=subprocess.run([sys.executable,str(source/'tools'/(name+'.py'))],cwd=source,stdout=log,stderr=subprocess.STDOUT)
 results[name]={'exit_code':p.returncode};(o/'additional-results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,p.returncode,flush=True)
