import subprocess,sys,json,hashlib
from pathlib import Path
root=Path.cwd();out=root/'build/rc564-conformance';base=root/'build/rc564-systems/z80pack';suite=root/'build/rc564-conformance-suite';sim=root/'build/rc564-runtime/z80pack/cpmsim/cpmsim'
original=dict(line.split()[1:][0:1] and (line.split()[1],line.split()[0]) for line in (suite/'suite/build/SHA256SUMS.txt').read_text().splitlines())
pinned=subprocess.check_output(['git','-C',str(suite),'show','HEAD:suite/build/SHA256SUMS.txt'],text=True)
assert original=={line.split()[1]:line.split()[0] for line in pinned.splitlines()}
results={}
for prog in ('CCPTEST','ENTRYTST','ECOTEST','CPUTEST','BDOSTEST','DIRTEST','FILETEST','RANDTEST','DISKTEST','BIOSTEST','ERRTEST'):
 print('Running',prog,flush=True)
 cmd=[sys.executable,'tools/run_validation_returning.py','--baseline',str(base),'--diskdefs',str(base/'diskdefs'),'--suite',str(suite),'--output',str(out/'returning'),'--program',prog,'--simulator',str(sim)]
 if prog=='FILETEST':cmd+=['--file-required']
 if prog=='DISKTEST':cmd+=['--disk-required']
 with (out/(prog+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 results[prog]={'exit_code':r.returncode}
 (out/'runner-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(prog,'exit',r.returncode,flush=True)
for label,tool in [('console-output','run_validation_console.py'),('console-input','run_validation_console_input.py'),('readonly','run_validation_readonly_outcomes.py'),('ecology','run_validation_resident_ecology.py')]:
 print('Running',label,flush=True)
 cmd=[sys.executable,'tools/'+tool,'--baseline',str(base),'--suite',str(suite),'--output',str(out/'external'/label),'--simulator',str(sim)]
 if label in ('console-output','console-input'):cmd+=['--diskdefs',str(base/'diskdefs')]
 with (out/(label+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 results[label]={'exit_code':r.returncode}
 (out/'runner-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(label,'exit',r.returncode,flush=True)
