import sys,json,os,subprocess,hashlib,copy
from pathlib import Path
sys.path.insert(0,'tools')
from component_inputs import capture
from component_revision import plan,accept
root=Path.cwd();out=root/'build/v101-review';ref=out/'reference';cand=out/'same-revision';assembler=Path.home()/'bin/z80asm'
keys=['RCP','DIR','USER','CLS','VER','COPY','MOVE'];original=json.loads((ref/'metadata/component-registry.json').read_text());final=json.loads((root/'metadata/component-registry.json').read_text())
env=dict(os.environ,BETTERCPM_IDENTITY_STATE='assigned')
def build(tree):
 with (out/'assignment-builds.log').open('a') as f:
  for name in ['build_rcp_cpx.py','build_rcp_transients.py']:subprocess.run(['python3',str(tree/'tools'/name)],env=env,check=True,stdout=f,stderr=subprocess.STDOUT)
def artifact(tree,name):return tree/('build/cpx/RCP.CPX' if name=='RCP' else 'build/utilities/'+name+'.COM')
def report(tree,name,target):
 b=artifact(tree,name).read_bytes();r=capture('utility:'+name,assembler,root=tree,target=target)
 return {'component':'utility:'+name,'identity':r['assigned_identity'],'artifact':{'name':artifact(tree,name).name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'input_record':r,'display_selection':{'development':False},'provenance':{'repository_commit':'16f9a479 (working changes)' if tree==root else 'review comparison tree'}},b
build(root)
catalog=json.loads((root/'metadata/component-baselines.json').read_text())
receipts=[]
for name in keys:
 registry=copy.deepcopy(final);registry['components']['utility:'+name]['revision']=original['components']['utility:'+name]['revision']
 (cand/'metadata/component-registry.json').write_text(json.dumps(registry,indent=2)+'\n')
 build(cand)
 for target in ['z80pack','trs80gp']:
  rr,rb=report(ref,name,target);cr,cb=report(cand,name,target);fr,fb=report(root,name,target)
  proposal=plan(rr,rb,cr,cb);accepted=accept(proposal,rr,rb,cr,cb,fr,fb)
  receipts.append(accepted);catalog['records']['|'.join(('utility:'+name,target,'default','cross'))]=accepted['input_record']
 print('accepted',name,flush=True)
(out/'assignments.json').write_text(json.dumps(receipts,indent=2,sort_keys=True)+'\n')
(root/'metadata/component-baselines.json').write_text(json.dumps(catalog,indent=2,sort_keys=True)+'\n')
