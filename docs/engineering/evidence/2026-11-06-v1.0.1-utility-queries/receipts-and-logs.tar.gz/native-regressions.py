import sys,runpy
from pathlib import Path
sys.path.insert(0,str(Path('tools').resolve()))
import test_z80pack_sysgen_install as driver
original=driver.session
sim=Path('../release-final/runtime/z80pack/cpmsim/cpmsim').resolve()
def session(ignored,*a,**kw):return original(sim,*a,**kw)
driver.session=session
for name in ['test_resident_copy_move_select','test_resident_type_media','test_resident_ren_select']:
 sys.argv=[name,'--platform','z80pack','--image-dir','build/v101-review/regression-base','--report','build/v101-review/operations-clean-'+name]
 print('RUN',name,flush=True)
 runpy.run_module(name,run_name='__main__')
