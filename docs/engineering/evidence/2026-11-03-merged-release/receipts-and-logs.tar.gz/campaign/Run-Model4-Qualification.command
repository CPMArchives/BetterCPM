#!/bin/zsh
set -eu
cd '/Users/nathanael/.codex/.chatgpt-projects/g-p-6a682f002be881918281554d644daf48/BetterCPM-release-merged'
export PYTHONDONTWRITEBYTECODE=1
exec /usr/bin/python3 -B tools/run_release_model4_conformance.py \
  --baseline "$PWD/build/merged232-ram-systems/trs80gp" \
  --suite "$PWD/../BetterCPM-release-push/build/rc564-conformance-suite" \
  --audit-blockers "$PWD/build/merged232-validation/model4-blockers" \
  --output "$HOME/Downloads/merged232-model4-$(date +%Y%m%d-%H%M%S)"
