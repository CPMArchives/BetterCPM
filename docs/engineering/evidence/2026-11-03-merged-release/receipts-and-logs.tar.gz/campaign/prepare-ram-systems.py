import sys,json,subprocess
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools'))
from build_distribution import ROOT,MANIFEST,source_identity,selected_files,geometry,capacity,construct,validate_config_fingerprint,validate_config_cold_patch,validate_files,digest,boot,stage_cpmsim_guest
from fdf_format import select_fdf
from build_z80pack_image import DEFAULT_FORMAT
from convert_fdf_image import raw_to_dmk
from test_utilities_inventory import inspect
from release_metadata import disk_record
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no']).strip()
identity=source_identity();manifest=json.loads(MANIFEST.read_text())
output=ROOT/'build/merged232-ram-systems';output.mkdir(exist_ok=False)
simulator=ROOT/'build/merged232-runtime/z80pack/cpmsim/cpmsim'
for target in ('trs80gp','z80pack'):
    if target=='z80pack':
        for arguments,name in ((['tools/build_z80pack_image.py','--ram-only','--system-tracks-only'],'ram-only-build'),(['tools/build_z80pack_bye.py'],'bye-build')):
            with (ROOT/'build/merged232-validation'/(name+'.log')).open('w') as log:
                subprocess.run([sys.executable,'-B',*arguments],stdout=log,stderr=subprocess.STDOUT,check=True)
        stage_cpmsim_guest(simulator,ROOT)
    out=output/target;out.mkdir()
    files,omitted=selected_files(manifest,target,ROOT);g=geometry(target,ROOT);totals=capacity(files,g)
    raw=construct(target,ROOT,out,files,g,manifest.get('cold_start_command',''))
    validate_config_fingerprint(target,raw,files,ROOT);validate_config_cold_patch(target,raw,files,ROOT)
    included=validate_files(raw,out,files,g)
    name='BetterCPM-Distribution-'+target+('-332K.dsk' if target=='z80pack' else '-80T-DS-System.dmk')
    if target=='trs80gp':
        from build_montezuma_extended_790k import build,verify
        image=build(raw.read_bytes());verify(image,require_blank=False)
    else:image=raw.read_bytes()
    path=out/name;path.write_bytes(image)
    fmt=select_fdf(ROOT/'third_party/montezuma'/('DISK-INT.FDF' if target=='trs80gp' else 'DISK.FDF'),'Montezuma Micro 80T DS DATA (80T, DS, DD, 800K)' if target=='trs80gp' else DEFAULT_FORMAT)
    blank=bytes([0xe5])*fmt.image_bytes;inspect(blank,fmt,{})
    work=raw_to_dmk(blank,fmt) if target=='trs80gp' else blank;(out/'work-image').write_bytes(work)
    result='PENDING normal-Terminal Model 4 execution' if target=='trs80gp' else boot(target,path,out,ROOT,simulator,Path('/unused'))
    report={'target':target,'image':name,'format':g['format'],'sha256':digest(image),'source':identity,'manifest_sha256':digest(MANIFEST.read_bytes()),'cold_start_command':manifest.get('cold_start_command',''),'included':included,'omitted':omitted,**totals,'status':'RAM CANDIDATE; NOT ACCEPTED','construction_mode':'Existing RAM-only system-track builder; no ROM qualification claim','validation':{'filesystem':'PASS','file_integrity':'PASS','config_fingerprint':'PASS','boot':result},'work_image_sha256':digest(work),'work_image_inventory':'PASS empty directory/allocation independent inspection','known_build_blocker':'Standard combined build fails ROM live-state template source inventory; retained separately'}
    if target=='z80pack':report['emulator_sha256']=digest(simulator.read_bytes())
    report['release_record']=disk_record(report,image,root=ROOT)
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(target,result,digest(image),flush=True)
