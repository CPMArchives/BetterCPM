#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
PATH=/Users/nathanael/projects/git/z80pack/cpmsim/srctools:"$PATH"
export PATH
exec python3 "$PWD/cpmsim_terminal.py" -- /Users/nathanael/projects/git/z80pack/cpmsim/cpmsim -z -d "$PWD/disks" "$@"
