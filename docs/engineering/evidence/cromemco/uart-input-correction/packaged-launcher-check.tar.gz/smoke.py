import os, pty, subprocess, sys, time
from pathlib import Path
root=Path('/Users/nathanael/Documents/ChatGPT/M 2/BetterCPM-cromemco')
sys.path.insert(0,str(root/'tools'))
from test_cromemco_system import Terminal
bundle=root/'build/cromemco-banner-package-smoke/BetterCPM-Cromemco-Engineering-macOS-arm64'
t=Terminal.__new__(Terminal)
t.master,slave=pty.openpty()
t.command=[str(bundle/'Run-Cromemco.command')]
t.process=subprocess.Popen(t.command,cwd='/tmp',stdin=slave,stdout=slave,stderr=slave)
os.close(slave)
t.data=bytearray();t.cursor=0;t.work=bundle.parent
try:
    t.expect('BetterCP/M 1.3 - Cromemco')
    t.prompt()
    time.sleep(1.5)
    t.send(':VER /BANNER','BetterCP/M 1.3 - Cromemco')
    t.cursor=len(t.data)
    for c in b'BYE\r':
        os.write(t.master,bytes([c]))
        time.sleep(.4)
    t.expect('System halted')
    t.process.wait(timeout=5)
    assert t.process.returncode==0
    print('PASS: packaged cold and explicit banners, launcher and clean exit')
finally:
    t.close()
