; Controller bring-up only: this is not a BetterCP/M system image.
        ASEG
        ORG 01000H
; Cromemco Z-1, FDC UART, 16FDC, 8-inch single-sided single-density.
CM_SSTAT EQU 000H
CM_SDATA EQU 001H
CM_FCMD EQU 030H
CM_FTRK EQU 031H
CM_FSEC EQU 032H
CM_FDATA EQU 033H
CM_FSEL EQU 034H

        LD A,0C0H
        OUT (CM_SSTAT),A
        LD A,1
        OUT (002H),A
        XOR A
        OUT (002H),A
        LD HL,CM_START
        CALL CM_STRING
        LD HL,0C000H
CM_RAM:
        LD (HL),055H
        LD A,(HL)
        CP 055H
        JP NZ,CM_FAIL
        LD (HL),0AAH
        LD A,(HL)
        CP 0AAH
        JP NZ,CM_FAIL
        INC HL
        LD A,H
        OR L
        JR NZ,CM_RAM
        LD HL,CM_RAMOK
        CALL CM_STRING
        LD HL,CM_INPUT
        CALL CM_STRING
        CALL CM_CONIN
        CP 'a'
        JP NZ,CM_FAIL
        LD HL,CM_INOK
        CALL CM_STRING
        LD A,1
        LD DE,00201H
        LD HL,02000H
        CALL CM_READ
        JP Z,CM_FAIL
        LD A,1
        LD HL,02000H
        CALL CM_WRITE
        JP Z,CM_FAIL
        LD HL,CM_FMSG
        CALL CM_STRING
        JP CM_EXIT
CM_FMSG: DB 'MEDIA ERROR PASS',13,10,0

        XOR A
        LD (CM_DRV),A
CM_DRIVES:
        LD A,(CM_DRV)
        LD DE,00201H
        LD HL,02000H
        CALL CM_READ
        JP NZ,CM_FAIL
        LD A,(CM_DRV)
        ADD A,040H
        CALL CM_CHECK
        LD A,(CM_DRV)
        LD DE,04C1AH
        LD HL,02000H
        CALL CM_READ
        JP NZ,CM_FAIL
        LD A,(CM_DRV)
        ADD A,080H
        CALL CM_CHECK
        LD A,(CM_DRV)
        ADD A,0C0H
        LD HL,02000H
        LD B,128
CM_FILL:
        LD (HL),A
        INC HL
        DJNZ CM_FILL
        LD A,(CM_DRV)
        LD DE,00302H
        LD HL,02000H
        CALL CM_WRITE
        JP NZ,CM_FAIL
        LD HL,02000H
        LD B,128
CM_CLEAR:
        LD (HL),0
        INC HL
        DJNZ CM_CLEAR
        LD A,(CM_DRV)
        LD HL,02000H
        CALL CM_READ
        JP NZ,CM_FAIL
        LD A,(CM_DRV)
        ADD A,0C0H
        CALL CM_CHECK
        LD A,(CM_DRV)
        INC A
        LD (CM_DRV),A
        CP 4
        JR NZ,CM_DRIVES
        LD HL,CM_IOOK
        CALL CM_STRING
        LD A,4                      ; drive outside A-D must fail
        LD DE,00201H
        CALL CM_READ
        JP Z,CM_FAIL
        XOR A
        LD DE,04D01H                ; track 77 must fail
        CALL CM_READ
        JP Z,CM_FAIL
        XOR A
        LD DE,00200H                ; sector zero must fail before I/O
        CALL CM_READ
        JP Z,CM_FAIL
        XOR A
        LD DE,0021BH                ; sector 27 must fail
        CALL CM_READ
        JP Z,CM_FAIL
        LD HL,CM_ERROROK
        CALL CM_STRING
        LD HL,CM_OK
        CALL CM_STRING
        JP CM_EXIT
CM_FAIL:
        LD HL,CM_MSGNG
        CALL CM_STRING
CM_EXIT:
        LD A,0AAH
        OUT (0A0H),A
        LD A,080H
        OUT (0A0H),A
        HALT
CM_CHECK:
        LD HL,02000H
        LD B,128
CM_COMPARE:
        CP (HL)
        JP NZ,CM_FAIL
        INC HL
        DJNZ CM_COMPARE
        RET
CM_DRV: DB 0
CM_START: DB 'CROMEMCO Z80 16FDC BOOT',13,10,0
CM_RAMOK: DB 'ROM RECLAIM AND UPPER 16K RAM PASS',13,10,0
CM_INPUT: DB 'SEND a',13,10,0
CM_INOK: DB 'CONSOLE INPUT PASS',13,10,0
CM_IOOK: DB 'FOUR DRIVE READ WRITE PASS',13,10,0
CM_ERROROK: DB 'INVALID ADDRESS PASS',13,10,0
CM_OK: DB 'CROMEMCO PROBE PASS',13,10,0
CM_MSGNG: DB 'CROMEMCO PROBE FAIL',13,10,0
; Poll the FDC UART, which has RDA on bit 6 and TBE on bit 7.
; The pinned UART emulator strips output parity (seven-bit console).
CM_CONST:
        IN A,(CM_SSTAT)
        AND 040H
        RET
CM_CONIN:
        CALL CM_CONST
        JR Z,CM_CONIN
        IN A,(CM_SDATA)
        RET
CM_CONOUT:
        IN A,(CM_SSTAT)
        AND 080H
        JR Z,CM_CONOUT
        LD A,C
        OUT (CM_SDATA),A
        RET
CM_STRING:
        LD A,(HL)
        INC HL
        OR A
        RET Z
        LD C,A
        CALL CM_CONOUT
        JR CM_STRING

; A=drive 0..3, D=track 0..76, E=sector 1..26, HL=128-byte buffer.
; Returns A=0/Z success, A=1/NZ failure. Preserves DE, clobbers BC/HL.
; Fixed 8-inch SSSD, side zero. Restore and seek each request.
CM_READ:
        LD C,080H
        JR CM_TRANSFER
CM_WRITE:
        LD C,0A0H
CM_TRANSFER:
        CP 4
        JP NC,CM_IOBAD
        LD (CM_UNIT),A
        LD A,D
        CP 77
        JP NC,CM_IOBAD
        LD A,E
        DEC A
        CP 26
        JP NC,CM_IOBAD
        LD A,C
        LD (CM_COMMAND),A
        LD A,(CM_UNIT)
        LD B,A
        LD A,1
        INC B
CM_SELECT:
        DEC B
        JR Z,CM_SELON
        ADD A,A
        JR CM_SELECT
CM_SELON:
        OR 030H
        OUT (CM_FSEL),A
        LD A,0FFH
        OUT (004H),A
        LD A,0D0H
        OUT (CM_FCMD),A
        XOR A
        OUT (CM_FCMD),A
        CALL CM_IDLE
        JP NZ,CM_IOBAD
        IN A,(CM_FCMD)
        AND 004H
        JP Z,CM_IOBAD
        LD A,D
        OUT (CM_FDATA),A
        LD A,01CH
        OUT (CM_FCMD),A
        CALL CM_IDLE
        JP NZ,CM_IOBAD
        IN A,(CM_FCMD)
        AND 090H
        JP NZ,CM_IOBAD
        LD A,E
        OUT (CM_FSEC),A
        LD A,(CM_COMMAND)
        OUT (CM_FCMD),A
        LD B,128
CM_BYTE:
        LD C,0
CM_DRQ:
        IN A,(CM_FCMD)
        BIT 0,A
        JP Z,CM_IOBAD
        BIT 1,A
        JR NZ,CM_DATA
        DEC C
        JR NZ,CM_DRQ
        JP CM_IOBAD
CM_DATA:
        LD A,(CM_COMMAND)
        CP 080H
        JR NZ,CM_PUT
        IN A,(CM_FDATA)
        LD (HL),A
        JR CM_NEXT
CM_PUT:
        LD A,(HL)
        OUT (CM_FDATA),A
CM_NEXT:
        INC HL
        DJNZ CM_BYTE
        CALL CM_IDLE
        JP NZ,CM_IOBAD
        IN A,(CM_FCMD)
        AND 0FCH
        RET Z
CM_IOBAD:
        LD A,0D0H
        OUT (CM_FCMD),A
        LD A,1
        OR A
        RET
CM_IDLE:
        PUSH BC
        LD BC,0
CM_WAIT:
        IN A,(CM_FCMD)
        AND 1
        JR Z,CM_FINISHED
        DEC BC
        LD A,B
        OR C
        JR NZ,CM_WAIT
        INC A
CM_FINISHED:
        POP BC
        RET
CM_COMMAND: DB 0
CM_UNIT: DB 0

        END
