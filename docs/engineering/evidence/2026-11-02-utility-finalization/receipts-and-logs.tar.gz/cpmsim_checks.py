import sys,json,hashlib,subprocess,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'tools'))
from test_z80pack_sysgen_install import session
from run_utility_finalization_smoke import NAMES
from fdf_format import select_fdf
from build_z80pack_image import disk_definition,DEFAULT_FORMAT
from utility_versions import identities
w=root/'build/utility-finalization/cpmsim-continued';w.mkdir(exist_ok=False)
simulator=root/'build/rc557-runtime/z80pack/cpmsim/cpmsim'
system=Path.home()/'projects/git/BetterCPM/Releases/cpmsim/BetterCPM-Distribution-z80pack-332K.dsk'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result={'scope':'cpmsim booted utility help aliases/precedence and manager LIST; not full operational qualification','system_sha256':sha(system),'simulator_sha256':sha(simulator),'cases':[]}
fmt=select_fdf(root/'third_party/montezuma/DISK.FDF',DEFAULT_FORMAT)
previous=json.loads((root/'build/utility-finalization/cpmsim-final/result.json').read_text())
result['cases']=[c for c in previous['cases'] if c['status']=='PASS']
for c in result['cases']:
 assert sha(root/'build/utilities'/(c['name']+'.COM'))==c['sha256']
result['previous_receipt']='../cpmsim-final/result.json'
for name in NAMES[NAMES.index('ED'):]+['BYE']:
 f=(root/'build/z80pack-tools/BYE.COM') if name=='BYE' else root/'build/utilities'/(name+'.COM')
 work=w/name;work.mkdir();disks=work/'disks';disks.mkdir()
 (work/'diskdefs').write_text(disk_definition(fmt));b=disks/'driveb.dsk';b.write_bytes(b'\xe5'*fmt.image_bytes)
 subprocess.run(['cpmcp','-T','raw','-f','bettercpm-default',str(b),str(f),'0:'+name+'.COM'],cwd=work,check=True,capture_output=True)
 before=sha(b);shutil.copy2(system,disks/'drivea.dsk')
 case={'name':name,'sha256':sha(f),'status':'RUNNING'};result['cases'].append(case)
 version,revision=identities()[name]
 commands=[(('B:'+name+' /VER /h /BOGUS\r').encode(),('Usage: '+name).encode(),30),(b'',b'A0>_ ',30)]
 if name in ('CPX','RSX'):
  commands += [(('B:'+name+' list  \r').encode(),b'TPA available:',30),(b'',b'A0>_ ',30)]
 try:
  text=session(simulator,disks,commands,work/'transcript.bin')
  assert f'{name} {version} ({revision:03d}'.encode() in text,'wrong identification'
  assert b'/H /HELP' in text,'alias missing from help'
  assert sha(b)==before,'utility disk changed'
  case['status']='PASS'
 except Exception as e:
  case['status']='FAIL';case['error']=str(e)
 (w/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(name,case['status'],flush=True)
 if case['status']=='FAIL':break
assert sha(system)==result['system_sha256']
result['status']='PASS' if len(result['cases'])==len(NAMES)+1 and all(x['status']=='PASS' for x in result['cases']) else 'FAIL'
(w/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['status'])
