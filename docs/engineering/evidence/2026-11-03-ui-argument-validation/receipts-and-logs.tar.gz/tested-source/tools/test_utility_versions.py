#!/usr/bin/env python3
"""Version queries ignore other arguments and cannot invoke command work."""
from pathlib import Path
import re
from test_bios import Z80
from utility_versions import banner, identities, display_development
from component_registry import load
from component_identity import identification
ROOT=Path(__file__).resolve().parents[1]
def address(listing,name):
    equ=re.search(r"\b"+re.escape(name)+r"\s+EQU\s+0?([0-9a-f]+)H",listing,re.I)
    if equ:return int(equ[1],16)
    return int(re.search(r'^([0-9a-f]{4})\s+.*?\b'+name+':',listing,re.M|re.I)[1],16)
def runner(image,base=256):
    c=Z80(b'');c.mem[base:base+len(image)]=image
    # Record output service; a nonreturning WBOOT ends handled requests.
    c.mem[0:3]=bytes.fromhex("c3ffff")
    # A real CP/M entry is JP BDOS; guarded utilities use (0006h) as TPA
    # ceiling. An inline recording stub here made that word 0053h and caused
    # TED to return before its query path, falsely reporting missing output.
    c.mem[5:8]=bytes.fromhex('c300f0')
    c.mem[0xf000:0xf009]=bytes.fromhex('ed530070ed430270c9')
    return c
def output(c):
    assert c.word(0x7002)&255==9,('unexpected BDOS service',c.word(0x7002))
    p=c.word(0x7000);end=c.mem.index(36,p)
    return bytes(c.mem[p:end]).decode()
def expected_identification(name):
    """Current metadata-owned transient identity, including its full numeric block."""
    if name in ('DUMP','DDT'):
        from importlib import import_module
        return import_module('build_'+name.lower()).version_text()
    row=load()['components']['utility:'+name]
    if row.get('display_format')=='numeric':
        return identification(name,row['version'],row['revision'],row['description'],
                              development=display_development('utility:'+name))
    return banner(name)+'\r\n'

def main():
    from test_utility_finalization import execute
    count=0
    for name in identities():
        # The codecs and NOAH require the full Z80 harness (IX/IY).
        if name in ('RCP','SQ','USQ','CR','UNCR','LZH','UNLZH','BYE','DASM','DSYM','DLINK'):continue
        if name=='NOAH':
            print('NOAH: identity checks are in tools/test_noah.py (full Z80 core).')
            continue
        for tail in ['/VER',' /ver  ','/VER x','x /VER','/VER /VER','/VER /B','\t/VeR\tX','FILE\t/ver']:
            # Reuse the existing console collector: current utilities emit
            # either Function 9 strings or Function 2/6 character streams.
            actual,_=execute(name,tail)
            assert actual==expected_identification(name),(name,tail,actual);count+=1
    image=(ROOT/'build/cpx/rcp.bin').read_bytes()
    listing=(ROOT/'build/cpx/rcp.lst').read_text()
    for name in ['DIR','ERA','TYPE','REN','CLS','USER','VER','COPY','MOVE']:
        for arguments in ['/VER','X /VER Y','/VER /VER']:
            c=runner(image,0x8000);tail=(name+' '+arguments).encode();c.mem[0x6000:0x6000+len(tail)]=tail
            c.de=0x6000;c.b=len(tail);c.run(address(listing,'BC_COMMAND'),limit=100000)
            assert output(c)==banner(name,True)+'\r\n' and c.carry,(name,arguments);count+=1
    for tail in ['', 'A0:*.COM', '/VERIFY', '/VERBOSE','X/VER','/VER=X',' /B A:FOO B: ']:
        c=runner(image,0x8000);data=tail.encode();c.mem[0x6000:0x6000+len(data)]=data
        c.hl=0x6000;c.bc=len(data)*256+77;c.de=0x4567
        before=(c.hl,c.bc,c.de);c.run(address(listing,'UV_QUERY'),limit=100000)
        assert not c.carry and (c.hl,c.bc,c.de)==before and c.word(0x7002)==0,tail;count+=1
    print(f'{count} utility identity, resident dispatch, forgiving query arguments, and pure fall-through checks pass')
if __name__=='__main__':main()
