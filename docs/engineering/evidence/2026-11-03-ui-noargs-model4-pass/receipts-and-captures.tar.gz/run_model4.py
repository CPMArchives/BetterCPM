import json,subprocess
from pathlib import Path
w=Path(__file__).resolve().parent
subprocess.run(json.loads((w/"invocation.json").read_text()),cwd=w,check=True)
