from pathlib import Path
import sys,json,subprocess,hashlib
sys.path.insert(0,'/private/tmp/bettercpm-sq-command-20261023/tools')
from add_cpm_file_to_dmk import extract_raw
from build_z80pack_image import disk_definition,DEFAULT_FORMAT
from fdf_format import select_fdf
root=Path('/private/tmp/bettercpm-sq-command-20261023');work=Path('/private/tmp/utility-reacceptance-query-media');system=Path('/private/tmp/utility-reacceptance-final-system/release-dc2008b12f14-8a1c620ab109')
result=json.loads((work/'report.json').read_text());assert result['status']=='PASS'
audits={}
for platform in ('z80pack','trs80gp'):
 w=work/platform;original=json.loads((system/platform/'report.json').read_text());native=platform=='trs80gp';definition='query-system' if native else 'bettercpm-default'
 if native:
  image=w/'after.raw';image.write_bytes(extract_raw((w/'a.dmk').read_bytes()))
  (w/'diskdefs').write_text('diskdef query-system\n libdsk:format pcw800\n seclen 512\n tracks 160\n sectrk 10\n blocksize 2048\n maxdir 128\n skew 1\n boottrk 4\n os 2.2\nend\n')
 else:image=w/'disks/drivea.dsk'
 checked=[]
 for item in original['included']:
  if native and item['name']=='STARTUP.SUB':continue
  path=w/('shipped-after-'+item['name']);path.unlink(missing_ok=True)
  subprocess.run(['cpmcp','-T','raw','-f',definition,str(image),'0:'+item['name'],str(path)],cwd=w,check=True,capture_output=True)
  data=path.read_bytes();assert len(data)>=item['bytes']
  assert hashlib.sha256(data[:item['bytes']]).hexdigest()==item['sha256'],(platform,item['name'])
  checked.append(item['name'])
 fs=subprocess.run(['fsck.cpm','-T','raw','-f',definition,'-n',str(image)],cwd=w,capture_output=True);(w/'filesystem-after.txt').write_bytes(fs.stdout+fs.stderr);assert fs.returncode==0
 audits[platform]={'status':'PASS','unchanged_shipped_files':checked,'excluded_fixture':'STARTUP.SUB replaced intentionally for native query batch' if native else None,'filesystem':'PASS'}
(work/'after-audit.json').write_text(json.dumps(audits,indent=2)+'\n');print('PASS all original shipped files preserved after queries (native STARTUP fixture excepted); both filesystems clean')
