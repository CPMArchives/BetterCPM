from pathlib import Path
import sys,json,subprocess,hashlib
sys.path.insert(0,'/private/tmp/bettercpm-sq-command-20261023/tools')
from add_cpm_file_to_dmk import extract_raw
from test_model4_copy import files
w=Path('/private/tmp/utility-reacceptance-gate-probe');raw=extract_raw((w/'b.dmk').read_bytes());current=files(raw)
def key(user,name):a,b=name.split('.');return user,(a.ljust(8)+b.ljust(3)).encode()
want=b'ALPHA\r\nBETA\r\n'
for u,n in ((1,'SOURCE.TXT'),(1,'RCOPY.TXT'),(3,'CCOPY.TXT')):assert current[key(u,n)][0].split(b'\x1a')[0]==want
assert key(1,'PCOPY.TXT') not in current
assert not(current[key(3,'CCOPY.TXT')][1][0][9]&128)
assert current[key(7,'CASE.TXT')][0].split(b'\x1a')[0]==b'OLD\r\n'
assert current[key(0,'CASE.TXT')][0].split(b'\x1a')[0]==b'USER ZERO\r\n'
assert set(current)=={key(u,n) for u,n in ((1,'SOURCE.TXT'),(1,'RCOPY.TXT'),(3,'CCOPY.TXT'),(7,'CASE.TXT'),(0,'CASE.TXT'))}
(w/'b-after.raw').write_bytes(raw);(w/'diskdefs').write_text('diskdef data\n libdsk:format pcw800\n seclen 512\n tracks 160\n sectrk 10\n blocksize 2048\n maxdir 128\n skew 1\n boottrk 0\n os 2.2\nend\n')
r=subprocess.run(['fsck.cpm','-T','raw','-f','data','-n',str(w/'b-after.raw')],cwd=w,capture_output=True);(w/'filesystem.txt').write_bytes(r.stdout+r.stderr);assert r.returncode==0
(w/'result.json').write_text(json.dumps({'status':'PASS','scope':'First native file-workflow phase only: PIP, COPY, STAT R/O+R/W, DIR/WHEREIS, REN, TYPE; no claim for remaining ED/lifecycle/reboot phases','key_hold_ms':250,'settle_ms':1000,'file_bytes_attributes_and_other_users_preserved':True,'filesystem':'PASS','data_image_sha256':hashlib.sha256((w/'b.dmk').read_bytes()).hexdigest()},indent=2)+'\n')
print('PASS native first file-workflow phase: exact PIP/COPY/REN bytes, STAT final R/W, source/other users preserved, filesystem clean')
