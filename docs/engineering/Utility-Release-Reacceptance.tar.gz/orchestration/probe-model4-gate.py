from pathlib import Path
import json,shutil,sys
sys.path.insert(0,'/private/tmp/bettercpm-sq-command-20261023/tools')
from trs80gp_launch import run
source=next(Path('/private/tmp/utility-reacceptance-system-workflow-model4').glob('applications-*'))
w=Path('/private/tmp/utility-reacceptance-gate-probe');w.mkdir()
for name in ('a.dmk','b.dmk'):shutil.copy2(source/name,w/name)
cmd=json.loads((source/'invocation.json').read_text());stop=cmd.index('WFGATEA READY')-1;cmd=cmd[:stop]+['-iw','WFGATEA READY','-id','1000','-it','-ix']
for name in ('a.dmk','b.dmk'):cmd=[str(w/name) if x==str(source/name) else x for x in cmd]
# Hold the native matrix key beyond one scan/debounce interval.
for i in range(len(cmd)-1):
 if cmd[i]=='-id' and cmd[i+1]=='60':cmd[i+1]='250'
 elif cmd[i]=='-id' and cmd[i+1]=='120':cmd[i+1]='1000'
 if cmd[i]=='-itime':cmd[i+1]='60000'
(w/'invocation.json').write_text(json.dumps(cmd,indent=2)+'\n');run(cmd,cwd=w,timeout=300)
qs=sorted(w.glob('trs80-text*'));assert len(qs)==2
last=bytes(x&127 for x in qs[-1].read_bytes()[:1920]);assert b'WFGATEA READY' in last and b'ALPHA' in last and b'BETA' in last
print('PASS Model 4 first workflow gate with 250ms matrix key hold and 1s settling')
