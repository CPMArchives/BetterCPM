from pathlib import Path
import hashlib,json,subprocess,time,sys
root=Path('/private/tmp/utility-reacceptance-artifacts/z80pack')
out=Path('/private/tmp/utility-reacceptance-focused');out.mkdir(exist_ok=False)
names='''utility_versions version_stack ver_banner release_identity
stat_parser stat_size stat_sort stat_dpb stat_capacity stat_devices stat_attribute_result
dir_filespec dir_columns dir_metrics dir_sort dir_whereis dir_attributes dir_options dir_collection dir_free dir_transient_select
copy_filespec copy_mapping copy_reporting copy_shared_input
config_command_line config_iobyte config_startup_read config_startup_save config_logical_cli config_physical_cli config_edit_cli config_saved_inspection config_validation
sysgen_command_line sysgen_shared_choice sysgen_shared_destination sysgen_package_validation
dup_command_line dup_shared_choice dup_shared_menus
ren_core ren_failure ren_collision ren_workflow ren_shared_choice ren_shared_name ren_protection
type_files type_streaming type_paging type_limits type_output_abort
pip_parser pip_transfer pip_transform pip_concat pip_extract pip_hex pip_block pip_devices pip_shared_confirmation pip_operands pip_wildcard pip_number pip_input
ed_invocation ed_input ed_finish ed_return ed_files ed_publish ed_recovery ed_exit
time_set time_errors time_artifacts
era_raw_adapter era_shared_choice era_destructive_plan
cpx_control rsx_runtime_overlays
dump_enhanced dump dd t'''.split()
names=[x for x in names if x not in ('dd','t')]+['ddt','ddt_input']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
artifacts=sorted((root/'build/utilities').glob('*.COM'))+[root/'build/cpx/RCP.CPX',root/'build/rsx/BATCHIO.RSX']
before={str(p.relative_to(root)):sha(p) for p in artifacts}
rows=[]
for name in names:
 script=root/'tools'/('test_'+name+'.py');start=time.time()
 with (out/(name+'.log')).open('wb') as stream:
  try:
   r=subprocess.run([sys.executable,str(script)],cwd=root,stdout=stream,stderr=subprocess.STDOUT,timeout=90)
   code=r.returncode
  except subprocess.TimeoutExpired:code=124
 rows.append({'test':str(script.relative_to(root)),'source_sha256':sha(script),'status':'PASS' if code==0 else 'FAIL','exit_code':code,'seconds':round(time.time()-start,2),'log_sha256':sha(out/(name+'.log'))})
 (out/'report.json').write_text(json.dumps({'status':'IN_PROGRESS','artifacts':before,'tests':rows},indent=2)+'\n')
 print(name,rows[-1]['status'],flush=True)
after={str(p.relative_to(root)):sha(p) for p in artifacts}
assert before==after,'tests changed accepted artifacts'
(out/'report.json').write_text(json.dumps({'status':'PASS' if all(x['status']=='PASS' for x in rows) else 'FAIL','artifacts':before,'artifacts_unchanged':True,'tests':rows},indent=2)+'\n')
