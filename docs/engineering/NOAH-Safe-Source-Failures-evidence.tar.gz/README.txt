NOAH revision 9 safe source-preflight failure qualification, 2026-10-25.
builds/: completed native six-module ZSM4/LINK builds on both platforms.
final/: byte-verified reuse of those products and completed runtime campaigns.
The Model 4 keyboard runner allows Retry disk I/O to finish before sending Skip.
Incomplete earlier keyboard runs are excluded; compiled native groups and their
original execution receipts are retained. All products are checked against the
self-contained six-module cross/native sources under final/cross/.
host/: 21 focused source-failure transactions and existing regression suites.
source/: changed maintained implementation/build/test/metadata inputs.
Disk images and assembler listings are omitted. Filesystem, invocation/execution,
console traces and extracted outputs remain, with hashes in MANIFEST.json.
Native tests cover Retry/Skip and unattended failure; physical I/O/close failures
and Abort are fault-injected assembled-code tests, not native disk-error injection.
This is not full NOAH completion or Utilities media acceptance.
