
#include "simdefs.h"
#include "simglb.h"
#include "simz80.h"
BYTE memory[65536];
BYTE io_in(BYTE l, BYTE h) { return 0; }
void io_out(BYTE l, BYTE h, BYTE d) {}
void end_bus_request(void) { bus_mode=0; }
void sleep_for_us(unsigned long n) {}
void sleep_for_ms(unsigned n) {}
uint64_t get_clock_us(void) { return 1; }
static void (*hook)(int);
static WORD readpc, writepc, retpc;
void set_hooks(WORD r, WORD w, void (*h)(int)) {
 readpc=r; writepc=w; hook=h;
}
int test_run(WORD address, int budget) {
 PC=address; SP-=2; memory[SP]=255; memory[(SP+1)&65535]=255;
 cpu_error=0; tmax=100000000;
 for(int i=0;i<budget;i++) {
  if(PC==65535) return i;
  if(PC==0) return i;
  if(retpc && PC==retpc) { retpc=0; if(hook) hook(1); }
  if(PC==5) { retpc=memory[SP]|memory[(SP+1)&65535]<<8; if(hook) hook(0); }
  if(PC>=59793 && PC<59844 && (PC-59793)%3==0) { if(hook) hook(2); }
  if(PC==65535) return i;
  cpu_state=ST_SINGLE_STEP; cpu_z80();
  if(cpu_error) return -cpu_error;
 }
 return -1000;
}
