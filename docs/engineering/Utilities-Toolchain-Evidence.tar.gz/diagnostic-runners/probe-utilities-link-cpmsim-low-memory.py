from pathlib import Path
import sys,subprocess,shutil,json
root=Path('/private/tmp/bettercpm-sq-command-20261023');sys.path.insert(0,str(root/'tools'))
from test_z80pack_sysgen_install import session
from build_z80pack_image import disk_definition,DEFAULT_FORMAT
from fdf_format import select_fdf
w=Path('/private/tmp/utilities-toolchain-cpmsim-low-memory2');w.mkdir(exist_ok=False);(w/'disks').mkdir()
reference=Path('/private/tmp/utility-reacceptance-final-system/release-dc2008b12f14-8a1c620ab109/z80pack');r=json.loads((reference/'report.json').read_text());shutil.copy2(reference/r['image'],w/'disks/drivea.dsk')
for n in 'bcd':shutil.copy2('/private/tmp/utilities-toolchain-final-images/BetterCPM-Utilities-z80pack-332K.dsk',w/f'disks/drive{n}.dsk')
(w/'diskdefs').write_text(disk_definition(select_fdf(root/'third_party/montezuma/DISK.FDF',DEFAULT_FORMAT)))
old=Path('/private/tmp/utilities-toolchain-model4-gated/trs80gp/CR')
subprocess.run(['cpmcp','-T','raw','-f','toolchain-system',str(old/'system.raw'),'0:COMMAND.REL',str(w/'COMMAND.REL')],cwd=old,check=True)
subprocess.run(['cpmcp','-T','raw','-f','bettercpm-default',str(w/'disks/drivea.dsk'),str(w/'COMMAND.REL'),'0:COMMAND.REL'],cwd=w,check=True)
for name,data in {'LOWTEST.SUB':b'RSX LOAD ANSISCRN\r\nRSX LOAD ADM3A\r\nSTAT MEM\r\nB:LINK COMMAND[A]\r\nMARK\r\n\x1a','MARK.COM':bytes.fromhex('110b010e09cd0500c30000')+b'LOWMEM DONE\r\n$'}.items():
 (w/name).write_bytes(data)
 subprocess.run(['cpmcp','-T','raw','-f','bettercpm-default',str(w/'disks/drivea.dsk'),str(w/name),'0:'+name],cwd=w,check=True)
commands=[(b'SUBMIT LOWTEST\r',b'LOWMEM DONE',120)]
log=session(Path('/private/tmp/cpmsim-release-runtime/z80pack/cpmsim/cpmsim'),w/'disks',commands,w/'transcript.bin');print(log.decode(errors='replace')[-4000:])
subprocess.run(['cpmcp','-T','raw','-f','bettercpm-default',str(w/'disks/drivea.dsk'),'0:COMMAND.COM',str(w/'COMMAND.COM')],cwd=w,check=True)
if (w/'COMMAND.COM').exists():
 expected=(root/'build/utilities/CR.COM').read_bytes();assert (w/'COMMAND.COM').read_bytes()[:len(expected)]==expected;print('PASS paired cpmsim CR LINK parity')
