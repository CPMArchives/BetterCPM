from pathlib import Path
import sys,subprocess,shutil
r=Path('/private/tmp/bettercpm-sq-command-20261023');sys.path.insert(0,str(r/'tools'))
from build_ccp import assemble
from test_z80pack_sysgen_install import session
w=Path('/private/tmp/utilities-toolchain-sequential-probe');w.mkdir(exist_ok=False)
s=''' ORG 100H
 LD SP,9000H
 LD C,22
 LD DE,FCB
 CALL 5
 LD B,128
LOOP: PUSH BC
 LD C,21
 LD DE,FCB
 CALL 5
 POP BC
 OR A
 JP NZ,FAIL
 DJNZ LOOP
 LD DE,AFTERWRITE
 CALL PRINT
 CALL DUMP
 LD C,16
 LD DE,FCB
 CALL 5
 PUSH AF
 LD DE,AFTERCLOSE
 CALL PRINT
 POP AF
 CALL HEX
 CALL DUMP
 LD HL,FCB+12
 INC (HL)
 LD C,15
 LD DE,FCB
 CALL 5
 PUSH AF
 LD DE,AFTEROPEN
 CALL PRINT
 POP AF
 CALL HEX
 CALL DUMP
 LD DE,DONE
 CALL PRINT
 JP 0
FAIL: LD DE,BAD
 CALL PRINT
 JP 0
DUMP: LD HL,FCB
 LD B,36
DLOOP: PUSH BC
 PUSH HL
 LD A,(HL)
 CALL HEX
 POP HL
 POP BC
 INC HL
 DJNZ DLOOP
 LD DE,NL
 JP PRINT
HEX: PUSH AF
 RRCA
 RRCA
 RRCA
 RRCA
 CALL NIB
 POP AF
NIB: AND 15
 ADD A,30H
 CP 3AH
 JR C,HOK
 ADD A,7
HOK: LD E,A
 LD C,2
 JP 5
PRINT: LD C,9
 JP 5
AFTERWRITE: DB 'WRITE ','$'
AFTERCLOSE: DB 'CLOSE ','$'
AFTEROPEN: DB 'OPEN ','$'
NL: DB 13,10,'$'
DONE: DB 'SEQUENCE PROBE DONE',13,10,'$'
BAD: DB 'SEQUENCE WRITE FAILED',13,10,'$'
FCB: DB 0,'SEQTEST DAT'
 DB '''+','.join(['0']*24)+'''\n END\n'''
(w/'probe.asm').write_text(s);assemble(Path.home()/'bin/z80asm',s,w/'SEQPROBE.COM',w/'probe.lst',0x100)
b=Path('/private/tmp/cpmsim-release-runtime/z80pack/cpmsim');lib=b/'disks/library';d=w/'disks';d.mkdir();shutil.copy2(lib/'cpm22-62khd.dsk',d/'drivea.dsk')
for n in 'bcd':shutil.copy2(lib/'cpm22-1.dsk',d/f'drive{n}.dsk')
subprocess.run(['cpmcp','-f','ibm-3740',str(d/'drivea.dsk'),str(w/'SEQPROBE.COM'),'0:SEQPROBE.COM'],check=True)
log=session(b/'cpmsim',d,[(b'SEQPROBE\r',b'SEQUENCE PROBE DONE',30)],w/'stock.bin',initial_prompt=b'A>');print(log.decode(errors='replace')[-1100:])
