from pathlib import Path
import sys,shutil,subprocess,json
root=Path('/private/tmp/bettercpm-sq-command-20261023');sys.path.insert(0,str(root/'tools'))
from add_cpm_file_to_dmk import extract_raw,add_file,FILESYSTEM_FIRST_SECTOR,SECTOR_SIZE,DIRECTORY_ENTRIES
from build_montezuma_extended_790k import build
from run_trs80_command import DEFAULT_EMULATOR,key_args
from trs80gp_launch import run
w=Path('/private/tmp/utilities-toolchain-link-memory-probe');w.mkdir(exist_ok=False)
original=Path('/private/tmp/utilities-toolchain-model4-gated/trs80gp/CR')
shutil.copy2(original/'diskdefs',w/'diskdefs');shutil.copy2(original/'b.dmk',w/'b.dmk')
raw=extract_raw((original/'a.dmk').read_bytes())
for i in range(DIRECTORY_ENTRIES):
 at=FILESYSTEM_FIRST_SECTOR*SECTOR_SIZE+i*32
 if raw[at]==0 and raw[at+1:at+12] in (b'STARTUP SUB',b'QUALIFY SUB',b'XXPROG  $$$'):raw[at]=0xe5
add_file(raw,'STARTUP.SUB',b'SUBMIT QUALIFY\r\n\x1a');add_file(raw,'QUALIFY.SUB',b'B:LINK COMMAND[A]\r\nTM1\r\n\x1a')
(w/'a.dmk').write_bytes(build(raw))
args=[str(DEFAULT_EMULATOR),'-m4','-batch','-turbo','-ktx','-d0',str(w/'a.dmk'),'-d1',str(w/'b.dmk'),'-itime','60000','-iw','TOOL CR STEP 1 DONE','-it']+key_args('\r',250)+['-id','1000','-ix']
(w/'invocation.json').write_text(json.dumps(args,indent=2));run(args,cwd=w,timeout=600)
(w/'after.raw').write_bytes(extract_raw((w/'a.dmk').read_bytes()))
for p in w.glob('trs80-text*'):
 b=bytes(c&127 for c in p.read_bytes()[:1920]);print('\n'.join(b[i:i+80].decode().rstrip() for i in range(0,len(b),80)).strip())
result=subprocess.run(['cpmcp','-T','raw','-f','toolchain-system',str(w/'after.raw'),'0:COMMAND.COM',str(w/'COMMAND.COM')],cwd=w,capture_output=True)
print('extract',result.returncode,result.stderr)
if (w/'COMMAND.COM').exists():
 expected=(root/'build/utilities/CR.COM').read_bytes();got=(w/'COMMAND.COM').read_bytes();assert got[:len(expected)]==expected;print('PASS CR links with no optional screen modules:',len(expected),'identical bytes')
