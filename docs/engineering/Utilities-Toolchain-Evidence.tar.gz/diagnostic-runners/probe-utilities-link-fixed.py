from pathlib import Path
import sys,subprocess,shutil,json,hashlib
root=Path('/private/tmp/bettercpm-sq-command-20261023');sys.path.insert(0,str(root/'tools'))
from add_cpm_file_to_dmk import extract_raw,add_file,FILESYSTEM_FIRST_SECTOR,SECTOR_SIZE,DIRECTORY_ENTRIES
from build_montezuma_extended_790k import build
from run_trs80_command import DEFAULT_EMULATOR,key_args
from trs80gp_launch import run
w=Path('/private/tmp/utilities-toolchain-link-fixed-probe');w.mkdir(exist_ok=False)
old=Path('/private/tmp/utilities-toolchain-model4-gated/trs80gp/CR')
source=next(Path('/private/tmp/utilities-toolchain-fixed-system-work5').glob('candidate-*/trs80gp/BetterCPM-Distribution-*.dmk'))
shutil.copy2(old/'diskdefs',w/'diskdefs');shutil.copy2(old/'b.dmk',w/'b.dmk')
raw=extract_raw(source.read_bytes());(w/'a.raw').write_bytes(raw)
subprocess.run(['cpmcp','-T','raw','-f','toolchain-system',str(old/'system.raw'),'0:COMMAND.REL',str(w/'COMMAND.REL')],cwd=old,check=True)
files={'COMMAND.REL':(w/'COMMAND.REL').read_bytes(),'TM1.COM':(old/'TM1.COM').read_bytes(),'MKEXT.COM':Path('/private/tmp/utilities-toolchain-make-extent-probe-ex2/MKEXT.COM').read_bytes()}
for name,b in files.items():
 (w/name).write_bytes(b);subprocess.run(['cpmcp','-T','raw','-f','toolchain-system',str(w/'a.raw'),str(w/name),'0:'+name],cwd=w,check=True)
raw=bytearray((w/'a.raw').read_bytes())
for i in range(DIRECTORY_ENTRIES):
 at=FILESYSTEM_FIRST_SECTOR*SECTOR_SIZE+i*32
 if raw[at]==0 and raw[at+1:at+12]==b'STARTUP SUB':raw[at]=0xe5
add_file(raw,'STARTUP.SUB',b'RSX LOAD M4SCRN\r\nRSX LOAD ADM3A\r\nSUBMIT QUALIFY\r\n\x1a');add_file(raw,'QUALIFY.SUB',b'MKEXT\r\nB:LINK COMMAND[A]\r\nTM1\r\n\x1a')
(w/'a.dmk').write_bytes(build(raw));args=[str(DEFAULT_EMULATOR),'-m4','-batch','-turbo','-ktx','-d0',str(w/'a.dmk'),'-d1',str(w/'b.dmk'),'-itime','60000','-iw','TOOL CR STEP 1 DONE','-it']+key_args('\r',250)+['-id','1000','-ix']
(w/'invocation.json').write_text(json.dumps(args,indent=2));(w/'reference-sha256.txt').write_text(hashlib.sha256(source.read_bytes()).hexdigest());run(args,cwd=w,timeout=600)
(w/'after.raw').write_bytes(extract_raw((w/'a.dmk').read_bytes()))
logs=[]
for p in w.glob('trs80-text*'):
 b=bytes(c&127 for c in p.read_bytes()[:1920]);logs.append(b);print('\n'.join(b[i:i+80].decode().rstrip() for i in range(0,len(b),80)).strip())
subprocess.run(['cpmcp','-T','raw','-f','toolchain-system',str(w/'after.raw'),'0:COMMAND.COM',str(w/'COMMAND.COM')],cwd=w,check=True)
expected=(root/'build/utilities/CR.COM').read_bytes();got=(w/'COMMAND.COM').read_bytes();assert got[:len(expected)]==expected
subprocess.run(['fsck.cpm','-T','raw','-f','toolchain-system','-n',str(w/'after.raw')],cwd=w,check=True)
(w/'result.json').write_text(json.dumps({'status':'PASS','system_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'cr_bytes':len(expected),'cr_sha256':hashlib.sha256(expected).hexdigest(),'rel_sha256':hashlib.sha256(files['COMMAND.REL']).hexdigest()},indent=2)+'\n');print('PASS corrected native CR LINK:',len(expected),'identical bytes')
