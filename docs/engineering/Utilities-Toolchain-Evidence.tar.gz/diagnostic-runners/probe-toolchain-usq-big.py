from pathlib import Path
import sys,subprocess,json,hashlib
sys.path.insert(0,'/private/tmp/bettercpm-sq-command-20261023/tools')
from add_cpm_file_to_dmk import extract_raw,add_file,FILESYSTEM_FIRST_SECTOR,SECTOR_SIZE,DIRECTORY_ENTRIES
from build_montezuma_extended_790k import build as system_dmk
from run_trs80_command import DEFAULT_EMULATOR,key_args
from trs80gp_launch import run
from convert_fdf_image import dmk_to_raw
from fdf_format import select_fdf
from test_model4_raw_geometry import read_file
from test_usq_com import padded
w=Path('/private/tmp/utilities-toolchain-usq-big-gated');w.mkdir()
root=Path('/private/tmp/bettercpm-sq-command-20261023')
f=select_fdf(root/'third_party/montezuma/DISK-INT.FDF','Montezuma Micro 80T DS DATA (80T, DS, DD, 800K)')
r=Path('/private/tmp/utilities-toolchain-final-system/release-8864aa58ca7a-11ade544a462/trs80gp');m=json.loads((r/'report.json').read_text());raw=bytearray(extract_raw((r/m['image']).read_bytes()))
for i in range(DIRECTORY_ENTRIES):
 at=FILESYSTEM_FIRST_SECTOR*SECTOR_SIZE+i*32
 if raw[at]==0 and raw[at+1:at+12]==b'STARTUP SUB':raw[at]=229
add_file(raw,'STARTUP.SUB',b'RSX LOAD M4SCRN\r\nRSX LOAD ADM3A\r\nSUBMIT QUALIFY\r\n\x1a')
add_file(raw,'QUALIFY.SUB',b'CLS\r\nB:USQ C:BIG.BQN C:\r\nMARK\r\n\x1a')
add_file(raw,'MARK.COM',bytes.fromhex('1110010e09cd05000e01cd0500c30000')+b'USQ BIG STEP DONE\r\n$')
(w/'a.dmk').write_bytes(system_dmk(raw));(w/'b.dmk').write_bytes(Path('/private/tmp/utilities-toolchain-final-images/BetterCPM-Utilities-trs80gp-80T-DS-800K.dmk').read_bytes());(w/'c.dmk').write_bytes(Path('/private/tmp/utilities-toolchain-final-compression/trs80gp/SQ/c.dmk').read_bytes())
args=[str(DEFAULT_EMULATOR),'-m4','-batch','-turbo','-ktx','-d0',str(w/'a.dmk'),'-d1',str(w/'b.dmk'),'-d2',str(w/'c.dmk'),'-itime','60000','-iw','USQ BIG STEP DONE','-it']+key_args('\r',250)+['-id','1000','-ix'];(w/'invocation.json').write_text(json.dumps(args,indent=2));run(args,cwd=w,timeout=600)
cs=list(w.glob('trs80-text-*'));log=b''.join(bytes(x&127 for x in p.read_bytes()[:1920]) for p in cs);(w/'console.bin').write_bytes(log);print(log.decode('ascii','replace'),flush=True)
assert b'USQ: complete.' in log
out=read_file(dmk_to_raw((w/'c.dmk').read_bytes(),f),f,0,'BIG.BIN');assert out==padded((bytes(range(256))*274)[:70001]);print('PASS gated native USQ 70016 bytes',flush=True)
