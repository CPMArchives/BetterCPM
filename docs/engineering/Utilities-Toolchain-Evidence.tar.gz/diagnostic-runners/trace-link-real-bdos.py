from pathlib import Path
import ctypes as C,sys,struct,subprocess,shutil,json
root=Path('/private/tmp/bettercpm-sq-command-20261023');sys.path.insert(0,str(root/'tools'))
from test_usq import SHIM
from system_layout import LAYOUT as L
from add_cpm_file_to_dmk import extract_raw
work=Path('/private/tmp/utilities-toolchain-link-bdos-trace');work.mkdir(exist_ok=True)
core=Path('/Users/nathanael/projects/git/z80pack/z80core');headers=core.parent/'z80sim/srcsim'
(work/'sim.h').write_text('#define DEF_CPU Z80\n#define EXCLUDE_I8080\n')
for n in ['simmem.h','simport.h']:shutil.copy2(headers/n,work/n)
shim=SHIM.replace('static WORD readpc, writepc;','static WORD readpc, writepc, retpc;')
old='''  if(hook && PC==readpc) hook(0);
  if(hook && PC==writepc) hook(1);'''
new=f'''  if(PC==0) return i;
  if(retpc && PC==retpc) {{ retpc=0; if(hook) hook(1); }}
  if(PC==5) {{ retpc=memory[SP]|memory[(SP+1)&65535]<<8; if(hook) hook(0); }}
  if(PC>={L['BIOS']} && PC<{L['BIOS']+51} && (PC-{L['BIOS']})%3==0) {{ if(hook) hook(2); }}
  if(PC==65535) return i;'''
assert old in shim;shim=shim.replace(old,new);(work/'shim.c').write_text(shim)
subprocess.run(['cc','-shared','-fPIC','-O2','-I'+str(work),'-I'+str(core),str(work/'shim.c'),str(core/'simglb.c'),*map(str,sorted(core.glob('simz80*.c'))),'-o',str(work/'core.so')],check=True)
lib=C.CDLL(str(work/'core.so'));mem=(C.c_ubyte*65536).in_dll(lib,'memory');reg={n:C.c_ubyte.in_dll(lib,n) for n in ['A','B','C','D','E','H','L']};reg.update({n:C.c_ushort.in_dll(lib,n) for n in ['SP','PC','IX','IY']});reg['F']=C.c_int.in_dll(lib,'F')
word=lambda a:mem[a]|mem[a+1]<<8
pair=lambda a,b:reg[a].value<<8|reg[b].value
setword=lambda a,v:mem.__setitem__(slice(a,a+2),v.to_bytes(2,'little'))
def setpair(a,b,v):reg[a].value=v>>8;reg[b].value=v&255
lib.test_run.argtypes=[C.c_ushort,C.c_int];lib.test_run.restype=C.c_int
for mode in ['native','cpmsim']:
 mem[:]=bytes(65536)
 if mode=='native':
  disks=[bytearray(extract_raw(Path('/private/tmp/utilities-toolchain-link-fixed-probe/a.dmk').read_bytes()))]
  spt,bsh,exm,dsm,off=40,4,0,389,4
 else:
  disks=[bytearray(Path('/private/tmp/utilities-toolchain-fixed-cpmsim/z80pack/CR/disks/drivea.dsk').read_bytes())]
  from fdf_format import select_fdf
  from build_z80pack_image import DEFAULT_FORMAT
  fmt=select_fdf(root/'third_party/montezuma/DISK.FDF',DEFAULT_FORMAT);spt,bsh,exm,dsm,off=fmt.spt,fmt.bsh,fmt.exm,fmt.dsm,fmt.reserved_records//fmt.spt
  mapping=fmt.raw_record_map()
 bios=L['BIOS'];base=L['BDOS'];binary=(root/'build/bdos/bdos.bin').read_bytes();mem[base:base+len(binary)]=binary
 link=(root/'third_party/dri-link/LINK.COM').read_bytes();mem[256:256+len(link)]=link
 mem[5]=0xc3;setword(6,L['TPA']);mem[L['TPA']]=0xc3;setword(L['TPA']+1,base)
 tail=b' COMMAND[A]';mem[128]=len(tail);mem[129:129+len(tail)]=tail;mem[129+len(tail)]=0
 mem[0x5c:0x5c+36]=bytes(1)+b'COMMAND    '+bytes(24)
 dph,dpb=0xe600,0xe640;mem[dph:dph+16]=struct.pack('<8H',0,0,0,0,0xef80,dpb,0xe800,0xe700)
 mem[dpb:dpb+15]=struct.pack('<HBBBHHBBHH',spt,bsh,(1<<bsh)-1,exm,dsm,127,0xc0,0,32,off)
 state={'dma':128,'track':0,'sec':0,'disk':0};events=[];console=[];current=None;error=[]
 def callback(kind):
  global current
  try:
   if kind==0:
    fn=reg['C'].value;de=pair('D','E');current={'fn':fn,'de':de,'before':bytes(mem[de:de+36]).hex() if fn>=15 and fn<=36 else ''};events.append(current)
   elif kind==1:
    if current is not None:
     current['a']=reg['A'].value;de=current['de'];current['after']=bytes(mem[de:de+36]).hex() if current['before'] else ''
   else:
    index=(reg['PC'].value-bios)//3
    if index==1:reg['PC'].value=65535;return
    if index in (2,3,7):reg['A'].value=0
    elif index in (4,5):console.append(reg['C'].value)
    elif index==8:state['track']=0
    elif index==9:
     state['disk']=reg['C'].value;setpair('H','L',dph if state['disk']==0 else 0)
    elif index==10:state['track']=pair('B','C')
    elif index==11:state['sec']=pair('B','C')
    elif index==12:state['dma']=pair('B','C')
    elif index in (13,14):
     sector=state['sec'] if mode=='native' else mapping[state['sec']]
     at=(state['track']*spt+sector)*128;dma=state['dma'];assert at+128<=len(disks[0]),(index,state,at)
     if index==13:mem[dma:dma+128]=disks[0][at:at+128]
     else:disks[0][at:at+128]=bytes(mem[dma:dma+128])
     reg['A'].value=0
    elif index==15:reg['A'].value=255
    elif index==16:setpair('H','L',pair('B','C'))
    else:raise AssertionError(('BIOS',index))
    sp=reg['SP'].value;reg['PC'].value=word(sp);reg['SP'].value=(sp+2)&65535
  except BaseException as e:error.append(repr(e));reg['PC'].value=65535
 hook=C.CFUNCTYPE(None,C.c_int)(callback);lib.set_hooks.argtypes=[C.c_ushort,C.c_ushort,C.CFUNCTYPE(None,C.c_int)];lib.set_hooks(5,65534,hook);reg['SP'].value=0xd000
 for n in ['A','B','C','D','E','H','L']:reg[n].value=0
 count=lib.test_run(256,100000000)
 (work/(mode+'-events.json')).write_text(json.dumps(events,indent=2));(work/(mode+'-console.bin')).write_bytes(bytes(console));(work/(mode+'-after.raw')).write_bytes(disks[0])
 print(mode,count,error,bytes(console).decode(errors='replace'))
 for e in events:
  if e['fn'] in (15,16,19,22) or (e['fn'] in (20,21,33,34) and e.get('a',0)!=0):print(e)
