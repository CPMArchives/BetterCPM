from pathlib import Path
import sys,shutil,subprocess
root=Path('/private/tmp/bettercpm-sq-command-20261023');sys.path.insert(0,str(root/'tools'))
from build_ccp import assemble
from test_z80pack_sysgen_install import session
w=Path('/private/tmp/utilities-toolchain-make-extent-probe-ex2');w.mkdir(exist_ok=False)
source=''' ORG 100H
 LD SP,9000H
 CALL RESET
 LD C,22
 LD DE,FCB
 CALL 5
 LD (STATUS),A
 LD DE,M0
 CALL PRINT
 CALL RESULT
 LD C,21
 LD DE,FCB
 CALL 5
 LD C,16
 LD DE,FCB
 CALL 5
 CALL RESET
 LD A,2
 LD (FCB+12),A
 LD C,22
 LD DE,FCB
 CALL 5
 LD (STATUS),A
 LD DE,M1
 CALL PRINT
 CALL RESULT
 LD DE,DONE
 CALL PRINT
 JP 0
RESET: LD HL,INITIAL
 LD DE,FCB
 LD BC,36
 LDIR
 RET
RESULT: LD A,(STATUS)
 PUSH AF
 RRCA
 RRCA
 RRCA
 RRCA
 CALL HEX
 POP AF
 CALL HEX
 LD DE,NL
 JP PRINT
HEX: AND 15
 ADD A,30H
 CP 3AH
 JR C,HOK
 ADD A,7
HOK: LD E,A
 LD C,2
 JP 5
PRINT: LD C,9
 JP 5
STATUS: DB 0
M0: DB 'MAKE EX0=','$'
M1: DB 'MAKE EX2=','$'
NL: DB 13,10,'$'
DONE: DB 'MAKE PROBE DONE',13,10,'$'
INITIAL: DB 0,'EXTMAKE DAT'
 DS 24
FCB: DS 36
 END
'''.replace(' DS 24',' DB '+','.join(['0']*24))
assemble(Path.home()/'bin/z80asm',source,w/'MKEXT.COM',w/'probe.lst',0x100);(w/'probe.asm').write_text(source)
base=Path('/private/tmp/cpmsim-release-runtime/z80pack/cpmsim');lib=base/'disks/library'
for name,system in [('stock',lib/'cpm22-62khd.dsk'),('better',Path('/private/tmp/utility-reacceptance-final-system/release-dc2008b12f14-8a1c620ab109/z80pack/BetterCPM-Distribution-z80pack-332K.dsk'))]:
 d=w/name;d.mkdir();shutil.copy2(system,d/'drivea.dsk')
 for n in 'bcd':shutil.copy2(lib/'cpm22-1.dsk',d/f'drive{n}.dsk')
 if name=='stock':fmt='ibm-3740'
 else:
  from build_z80pack_image import disk_definition,DEFAULT_FORMAT
  from fdf_format import select_fdf
  (w/'diskdefs').write_text(disk_definition(select_fdf(root/'third_party/montezuma/DISK.FDF',DEFAULT_FORMAT)));fmt='bettercpm-default'
 subprocess.run(['cpmcp','-T','raw','-f',fmt,str(d/'drivea.dsk'),str(w/'MKEXT.COM'),'0:MKEXT.COM'],cwd=w,check=True)
 log=session(base/'cpmsim',d,[(b'MKEXT\r',b'MAKE PROBE DONE',30)],w/(name+'.bin'),initial_prompt=b'A>' if name=='stock' else b'A0>_ ');print(name,log.decode(errors='replace')[-600:])
