#!/usr/bin/env python3
"""Build PIP.COM under native CP/M and require cross-build parity."""
from __future__ import annotations

import argparse
import os
import shutil
import tempfile
from pathlib import Path

from build_native_trs80 import (
    DEFAULT_CPMSIM, DEFAULT_SYSTEM, DEFAULT_TEMPLATE, DEFAULT_TOOLS,
    blank, cpm_text, run,
)

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src/utilities/pip.mac"
BUILD = ROOT / "build/pip-development"


def main() -> None:
    parser = argparse.ArgumentParser()
    base=Path.home()/'projects/git'
    runtime=base/'z80pack/cpmsim'
    parser.add_argument("--cpmsim", type=Path, default=DEFAULT_CPMSIM if DEFAULT_CPMSIM.is_file() else runtime/'cpmsim')
    parser.add_argument("--system-disk", type=Path, default=DEFAULT_SYSTEM if DEFAULT_SYSTEM.is_file() else runtime/'disks/library/cpm22-62khd.dsk')
    parser.add_argument("--disk-template", type=Path, default=DEFAULT_TEMPLATE if DEFAULT_TEMPLATE.is_file() else runtime/'disks/library/cpm22-1.dsk')
    parser.add_argument("--tools", type=Path, default=DEFAULT_TOOLS if DEFAULT_TOOLS.is_dir() else base/'cpm-compatibility/suite/build-tools')
    args = parser.parse_args()
    os.environ['PATH']=str(args.cpmsim.parent/'srctools')+os.pathsep+os.environ.get('PATH','')
    for path in (args.cpmsim, args.system_disk, args.disk_template,
                 args.tools / "ZSM4.COM", args.tools / "LINK.COM",
                 SOURCE, BUILD / "PIP.COM"):
        if not path.is_file():
            raise SystemExit(f"missing native-build input: {path}")

    with tempfile.TemporaryDirectory(prefix="bettercpm-native-pip-") as temporary:
        work = Path(temporary)
        disks = work / "disks"
        disks.mkdir()
        shutil.copy2(args.system_disk, disks / "drivea.dsk")
        for drive in "bcd":
            blank(args.disk_template, disks / f"drive{drive}.dsk")
        source = work / "PIP.MAC"
        from build_pip import expanded_source
        from build_native_rcp_transients import initialized_workspace
        import re
        text = initialized_workspace(expanded_source())
        text = re.sub(r'(?m)^\s+DS\s+(\d+)\s*$',
                      r'        REPT \1\n        DB 0FFH\n        ENDM', text)
        expanded = work / 'expanded.mac'
        expanded.write_text(text, encoding='ascii')
        source.write_bytes(cpm_text(expanded))
        run("cpmcp", "-f", "ibm-3740", str(disks / "drivec.dsk"),
            str(source), "0:PIP.MAC")
        for tool in ("ZSM4.COM", "LINK.COM"):
            run("cpmcp", "-f", "ibm-3740", str(disks / "drived.dsk"),
                str(args.tools / tool), f"0:{tool}")
        commands = f'''set timeout 60
spawn {args.cpmsim} -z -d {disks}
expect "A>"
send -- "B:\r"
expect "B>"
send -- "D:ZSM4 B:PIP=C:PIP\r"
expect -re {{Errors: +0}}
expect "B>"
send -- "D:LINK PIP\\[A\\]\r"
expect "CODE SIZE"
expect "B>"
send "\034"
expect eof
'''
        result = run("expect", "-c", commands, check=False)
        transcript = result.stdout + result.stderr
        (BUILD / "NATIVE-PIP-BUILD.LOG").write_text(transcript,
                                                      encoding="utf-8")
        if result.returncode or "Errors: 0" not in transcript or "CODE SIZE" not in transcript:
            raise SystemExit(f"native PIP build failed\n{transcript}")
        native_com = work / "PIP.COM"
        run("cpmcp", "-f", "ibm-3740", str(disks / "driveb.dsk"),
            "0:PIP.COM", str(native_com))
        cross = (BUILD / "PIP.COM").read_bytes()
        native = native_com.read_bytes()[:len(cross)]
        (BUILD / "PIP-native.COM").write_bytes(native)
        if native != cross:
            raise SystemExit(f"native/cross PIP mismatch: linked size {native_com.stat().st_size}")
        print(f"PIP: {len(native)} byte-identical bytes")


if __name__ == "__main__":
    main()
