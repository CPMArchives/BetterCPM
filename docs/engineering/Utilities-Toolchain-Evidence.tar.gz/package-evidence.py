from pathlib import Path
import hashlib,io,json,tarfile,gzip,subprocess,sys
root=Path('/private/tmp/bettercpm-sq-command-20261023');sys.path.insert(0,str(root/'tools'))
from toolchain_distribution import companions
sha=lambda b:hashlib.sha256(b).hexdigest()
reference=Path('/private/tmp/utilities-toolchain-final-system/release-8864aa58ca7a-11ade544a462')
campaigns=[Path('/private/tmp/utilities-toolchain-qualified-'+n) for n in ('cpmsim','model4-probe','model4-sq','model4-cr','model4-lzh')]
required={'PROBE','SQ','USQ','CR','UNCR','LZH','UNLZH'}
receipt={'status':'PASS','date':'2026-10-24','scope':'Packaged ZSM4 4.7 and DRI LINK 1.3 from Utilities B: on both BetterCP/M targets','baseline_revision':'8864aa58ca7a','tools_sha256':{n:sha((root/p/n).read_bytes()) for n,p in [('ZSM4.COM','third_party/zsm4'),('LINK.COM','third_party/dri-link')]},'companions_sha256':{n:sha(d) for n,d in companions(root).items()},'platforms':{},'independent_inventory':json.loads(Path('/private/tmp/utilities-toolchain-final-inventory.json').read_text()),'corresponding_source_verification':{'upstream_commit':'96a9ac1081172e1c08291521b77d2a715ec59c8b','files':154,'comparison':'complete archive member set and every file compared with pinned upstream Git objects'},'qualification_limit':'Component acceptance on exact paired media; final Utilities selection, whole-System conformance and protected-XIP release closure remain open.'}
for campaign in campaigns:
 report=json.loads((campaign/'report.json').read_text());audit=json.loads((campaign/'system-audit.json').read_text());assert report['status']=='PASS'
 for platform,proof in report['platforms'].items():
  assert proof['status']=='PASS' and set(proof['cases'])<=required
  sysreport=json.loads((reference/platform/'report.json').read_text());assert proof['system_sha256']==sysreport['sha256']
  for case in proof['cases']:assert proof['cases'][case]['status']=='PASS' and audit[platform+'/'+case]['status']=='PASS'
  p=receipt['platforms'].setdefault(platform,{'status':'PASS','system_sha256':proof['system_sha256'],'utilities_sha256':proof['utilities_sha256'],'system_audit_status':'PASS','cases':{},'campaigns':[]})
  assert p['system_sha256']==proof['system_sha256'] and p['utilities_sha256']==proof['utilities_sha256']
  assert not set(p['cases']) & set(proof['cases']);p['cases'].update(proof['cases'])
  p['campaigns'].append({'path':'campaigns/'+campaign.name,'report_sha256':sha((campaign/'report.json').read_bytes()),'system_audit_sha256':sha((campaign/'system-audit.json').read_bytes()),'runner_sha256':report['runner_sha256'],'runner_source':'campaigns/'+campaign.name+'/runner-executed.py','simulator_sha256':report['simulator_sha256'],'trs80gp_sha256':report['trs80gp_sha256']})
assert set(receipt['platforms'])=={'z80pack','trs80gp'}
for proof in receipt['platforms'].values():assert set(proof['cases'])==required
compression=Path('/private/tmp/utilities-toolchain-final-compression/report.json');cr=json.loads(compression.read_text());assert cr['compression_utilities_acceptance']=='PASS' and set(cr['platforms'])=={'z80pack','trs80gp'}
receipt['compression_reacceptance']={'status':'PASS','report_sha256':sha(compression.read_bytes()),'platforms':cr['platforms']}
receipt['kernel_correction']={'bdos_api':'1.2','implementation':'1.10','bdos_bytes':3436,'bdos_sha256':sha((root/'build/bdos/bdos.bin').read_bytes()),'extensions_bytes':425,'native_parity':{'bdos':sha((root/'build/bdos/bdos-native.bin').read_bytes()),'extensions':sha((root/'build/system/extensions-native.bin').read_bytes())},'make_cases':225,'sequential_boundary_cases':36,'random_position_cases':12,'extent_full_cases':12,'grouped_activation_cases':480,'original_core_boundary_regression':'EXPECTED failure; retained log','private_stack_reservation':40,'focused_extent_stack_high_water':32,'rom_packed_bytes':7939,'rom_spare_bytes':509,'rom_address_words':790,'config_overlay_words':105,'unexplained_or_unresolved_words':0,'live_protected_xip_acceptance':'not claimed'}
docs=root/'docs/engineering';index=docs/'Utilities-Toolchain-Qualification.json';index.write_text(json.dumps(receipt,indent=2)+'\n')
package=Path('/private/tmp/utilities-toolchain-qualified-package')
subprocess.run([sys.executable,str(root/'tools/build_utilities_disk.py'),'--artifacts','/private/tmp/utilities-toolchain-artifacts','--output',str(package),'--toolchain-acceptance',str(index)],cwd=root,check=True)
files={}
def add_tree(folder,prefix):
 for p in sorted(folder.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':files[prefix+'/'+str(p.relative_to(folder))]=p.read_bytes()
def add_file(path,prefix):
 p=Path(path)
 if p.is_file():files[prefix]=p.read_bytes()
for campaign in campaigns:add_tree(campaign,'campaigns/'+campaign.name)
add_tree(package,'package');add_tree(compression.parent,'compression-reacceptance')
for name in ('utilities-toolchain-cpmsim-probe','utilities-toolchain-cpmsim-probe2','utilities-toolchain-final-cpmsim','utilities-toolchain-final-model4','utilities-toolchain-model4-gated','utilities-toolchain-native-probe-screen','utilities-toolchain-fixed-cpmsim','utilities-toolchain-fixed-model4-probe','utilities-toolchain-fixed-model4-sq','utilities-toolchain-fixed-model4-cr','utilities-toolchain-fixed-model4-lzh','utilities-toolchain-link-memory-probe','utilities-toolchain-link-fixed-probe','utilities-toolchain-cpmsim-low-memory','utilities-toolchain-cpmsim-low-memory2','utilities-toolchain-make-extent-probe','utilities-toolchain-make-extent-probe-ex2','utilities-toolchain-sequential-probe','utilities-toolchain-sequential-full-probe','utilities-toolchain-random-boundary-probe','utilities-toolchain-link-bdos-trace','utilities-toolchain-final-rom','utilities-toolchain-usq-big-gated'):
 add_tree(Path('/private/tmp')/name,'diagnostics/'+name)
for target in ('z80pack','trs80gp'):
 report=json.loads((reference/target/'report.json').read_text())
 for name in ('report.json',report['image'],'build.log','boot.txt','filesystem-validation.txt'):add_file(reference/target/name,'reference-system/'+target+'/'+name)
for folder in ('third_party/zsm4','third_party/dri-link','src','tools','metadata'):
 add_tree(root/folder,'source/'+folder)
add_file(root/'third_party/z80pack/LICENSE','source/third_party/z80pack/LICENSE')
for path in Path('/private/tmp').glob('utilities-toolchain-*.log'):add_file(path,'host-logs/'+path.name)
for pattern in ('probe-utilities-link*.py','probe-link-*.py','trace-link-real-bdos.py','probe-toolchain-usq-big.py'):
 for path in Path('/private/tmp').glob(pattern):add_file(path,'diagnostic-runners/'+path.name)
for path in (root/'build/bdos').glob('NATIVE-*.LOG'):add_file(path,'native-core/'+path.name)
for path in (root/'build/system').glob('NATIVE-*.LOG'):add_file(path,'native-core/'+path.name)
for name in ('Utilities Toolchain Qualification.md','159 ROM-RAM Ownership Inventory.md'):
 add_file(docs/name,'records/'+name)
add_file(root/'docs/releases/1.0-ROADMAP.md','records/1.0-ROADMAP.md')
files['Utilities-Toolchain-Qualification.json']=index.read_bytes();files['package-evidence.py']=Path(__file__).read_bytes()
manifest={n:sha(d) for n,d in sorted(files.items())};files['SHA256SUMS.json']=(json.dumps(manifest,indent=2)+'\n').encode()
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
bundle=gzip.compress(buffer.getvalue(),mtime=0);bundlepath=docs/'Utilities-Toolchain-Evidence.tar.gz';bundlepath.write_bytes(bundle)
with tarfile.open(fileobj=io.BytesIO(bundle),mode='r:gz') as archive:
 assert len(archive.getmembers())==len(files)
 for member in archive.getmembers():
  data=archive.extractfile(member).read();assert data==files[member.name]
  if member.name!='SHA256SUMS.json':assert sha(data)==manifest[member.name]
(docs/'Utilities-Toolchain-SHA256SUMS.txt').write_text(sha(index.read_bytes())+'  '+index.name+'\n'+sha(bundle)+'  '+bundlepath.name+'\n')
print('PASS evidence archive:',len(files),'verified members,',len(bundle),'compressed bytes')
print('Package:',package/'BetterCPM-Utilities-package.zip')
