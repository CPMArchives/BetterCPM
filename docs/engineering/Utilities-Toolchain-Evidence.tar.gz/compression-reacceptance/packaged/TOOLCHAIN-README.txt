ZSM4 4.7 and Digital Research LINK 1.3

Distribute this complete package, including ZSM4-SOURCE.tar.gz,
with the Utilities images. It contains the complete corresponding
source, original build scripts, manuals, notices and GPL terms.
The disk images contain TOOLINFO.TXT, ZSM4COPY.TXT and LINKCOPY.TXT.
Toolchain-Provenance.json records exact versions, hashes and origins.
LINK-Permission.html retains the published CP/M permission.
