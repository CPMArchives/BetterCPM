#!/usr/bin/env python3
"""Build an independent cpmsim target; preserve the TRS-80 boot artifacts."""
from pathlib import Path
import argparse,re,struct,subprocess,sys,json,hashlib
from build_ccp import assemble
from fdf_format import select_fdf
from system_layout import LAYOUT as L
from cpm_tools_bundle import files as cpm_tools_files
from build_z80pack_rom_boot import build as build_rom_boot, z80pack_reloader_source
from build_rom_rsx_overlays import build as build_rom_rsx_overlays
from build_fdf_catalog import build as build_fdf_catalog
ROOT=Path(__file__).resolve().parents[1]
PLATFORM=ROOT/'src/platform/z80pack'
DEFAULT_FORMAT='California Computer Systems (40T, DS, DD, 332K)'

def symbols(path):
 result={}
 for address,name in re.findall(r'^([0-9a-f]{4})\s+.*?\b([A-Z][A-Z0-9_]*):',path.read_text(),re.M|re.I):
  result[name]=int(address,16)
 return result

def normalized(text):
 return text.replace('        CSEG\n        .PHASE  ','        ASEG\n        ORG     ').replace('        .DEPHASE\n','')

def disk_definition(fmt):
 # cpmtools skewtab entries are zero-based raw-sector ordinals.
 ordered_ids=sorted(fmt.sector_ids)
 logical_to_raw=[ordered_ids.index(sector_id) for sector_id in fmt.sector_ids]
 # cpmtools maps each logical physical sector through this zero-based table.
 skew=','.join(map(str,logical_to_raw))
 diskdefs=f'''diskdef bettercpm-default
 seclen {fmt.sector_bytes}
 tracks {fmt.raw_tracks}
 sectrk {fmt.physical_sectors}
 blocksize {fmt.block_bytes}
 maxdir {fmt.drm+1}
 skewtab {skew}
 boottrk {fmt.off}
 os 2.2
end
diskdef bettercpm-ccs-40ds
 seclen {fmt.sector_bytes}
 tracks {fmt.raw_tracks}
 sectrk {fmt.physical_sectors}
 blocksize {fmt.block_bytes}
 maxdir {fmt.drm+1}
 skewtab {skew}
 boottrk {fmt.off}
 os 2.2
end
'''
 # Pin LibDsk geometry: arbitrary CP/M directory bytes are not a boot BPB.
 # A large first file can otherwise be mistaken for an out-and-back format.
 diskdefs+='''diskdef bettercpm-mm-standard-system
 seclen 256
 tracks 40
 sectrk 18
 blocksize 2048
 maxdir 128
 skew 2
 boottrk 2
 os 2.2
end
diskdef bettercpm-mm-80t-ds-data
 libdsk:format pcw800
 seclen 512
 tracks 160
 sectrk 10
 blocksize 2048
 maxdir 128
 skew 2
 boottrk 0
 os 2.2
end
diskdef bettercpm-ampro-little-board
 seclen 512
 tracks 40
 sectrk 10
 blocksize 2048
 maxdir 64
 skew 0
 boottrk 2
 os 2.2
end
diskdef bettercpm-ampro-little-board-ds
 seclen 512
 tracks 80
 sectrk 10
 blocksize 2048
 maxdir 128
 skew 0
 boottrk 2
 os 2.2
end
'''
 return diskdefs


def main():
 p=argparse.ArgumentParser()
 p.add_argument('--output',type=Path,default=ROOT/'build/z80pack')
 p.add_argument('--assembler',type=Path,default=Path.home()/'bin/z80asm')
 p.add_argument('--simulator',type=Path,default=Path.home()/'projects/git/z80pack/cpmsim/cpmsim')
 p.add_argument('--format',default=DEFAULT_FORMAT,
                help='exact DISK.FDF format name')
 p.add_argument('--fdf',type=Path,default=ROOT/'third_party/montezuma/DISK.FDF')
 p.add_argument('--system-tracks-only',action='store_true',
                help='emit reserved system tracks and diskdefs for manifest-driven distribution')
 p.add_argument('--ram-only',action='store_true',help='build RAM system tracks without ROM artifacts')
 p.add_argument('--resident-only',action='store_true',
                help='stop after resident artifacts for shifted-layout analysis')
 args=p.parse_args();out=args.output.resolve()
 if args.ram_only and not args.system_tracks_only:p.error('--ram-only requires --system-tracks-only')
 fmt=select_fdf(args.fdf,args.format)
 record_map=fmt.raw_record_map()
 if fmt.reserved_records < 160:raise SystemExit(f'{fmt.name}: reserved area has {fmt.reserved_records} records; 160 required')
 if fmt.raw_tracks>255 or fmt.raw_track_bytes//128>255:raise SystemExit(f'{fmt.name}: bootstrap geometry exceeds 8-bit cpmsim ports')
 out.mkdir(parents=True,exist_ok=True)
 (out/'boot-format.json').write_text(json.dumps({'fdf':str(args.fdf.resolve()),'format':fmt.name})+'\n')
 disks=out/'disks'
 if disks.exists():raise SystemExit(f'{disks} exists; use a new --output to preserve test media')
 def asm(name,text,base,limit):
  data=assemble(args.assembler,normalized(text),out/(name+'.bin'),out/(name+'.lst'),base)
  if not data or len(data)>limit:raise ValueError(f'{name}: {len(data)} bytes exceeds {limit}')
  return data
 def read(path):return (ROOT/path).read_text()
 # Rebuild common software from current source. These are portable artifacts;
 # target BIOS, disk code, tables and overlays are kept only in our output.
 names=('bdos','fileloader') if args.resident_only else ('bdos','ccp','rcp_cpx','hello_cpx','rsxloader','rsxresolver','rsx_runtime_overlays','test_service_rsx','svctest','stateful_test_rsx','stattst','hello_rsx','echo_rsx','fdf_rsx','p2dos_rsx','zprtc_rsx','fileloader','utilities')
 for name in names:
  subprocess.run([sys.executable,str(ROOT/'tools'/f'build_{name}.py')],check=True,stdout=subprocess.DEVNULL)
 bios_source=read('src/bios/bios.mac')
 a=bios_source.index('BIOCONST:');b=bios_source.index('; ================================================================================',a)
 bios_source=bios_source[:a]+read('src/platform/z80pack/chario.inc')+bios_source[b:]
 bios_source=bios_source.replace('LD HL,02002H', 'LD HL,07337H')
 import re
 bios_source=re.sub(r'BIOLSTST:[^\n]*\n(?:.*\n)*?(?=BIOSECTR:)',
     'BIOLSTST:\n        LD A,(0003H)\n'+ '        RRCA\n'*6 +
     '        LD HL,IO_LS\n        JP IO_JUMP\n\n',bios_source,count=1)
 a=bios_source.index('BIOREAD:');b=bios_source.index('; LISTST',a)
 bios_source=bios_source[:a]+read('src/platform/z80pack/recordio.inc')+bios_source[b:]
 bios=asm('bios',bios_source.replace('        INCLUDE biosplat.inc',read('src/platform/z80pack/biosplat.inc')),L['BIOS'],L['FILE']-L['BIOS'])
 bs=symbols(out/'bios.lst');bc=symbols(ROOT/'build/bdos/bdos.lst')
 equ=lambda mapping,names:''.join(f'{k} EQU 0{mapping[k]:04X}H\n' for k in names)
 bioslinks=equ(bs,('BIO_DRIVE','BIO_TRACK','BIO_SECTOR','BIO_DMA','BIO_QUART'))
 disk_source=read('src/platform/z80pack/disk.mac').replace('        INCLUDE bioslinks.inc',bioslinks)
 disk_source=disk_source.replace('        INCLUDE bootfmt.inc',
                                 f'ZB_SLOTS EQU {fmt.raw_track_bytes//128}\n')
 disk_source=disk_source.replace('        DB ZB_MAP_BYTES',
                                 '        DB '+','.join(map(str,record_map)))
 disk_source=disk_source.replace('        REPT 4\n        DB 8,80,2,0,0,0\n        ENDM',
                                 '        REPT 4\n        DB 5,%d,%d,0,0,0\n        ENDM' % (fmt.cylinders,fmt.sides))
 disk=asm('disk',disk_source,L['DISK'],L['BIOS']-L['DISK'])
 core=equ(bc,('UB_DMA','UB_DRIVE','UB_USERNO','UB_COLUMN','UB_LISTE'))
 ext=asm('extensions',read('src/system/extens.mac').replace('        INCLUDE core.inc',core).replace('        INCLUDE versions.inc',read('src/bdos/versions.inc')),L['EXTENSIONS'],L['DISK']-L['EXTENSIONS'])
 es=symbols(out/'extensions.lst')
 ds=symbols(out/'disk.lst')
 config=read('src/platform/z80pack/config.mac')
 config=config.replace('        INCLUDE bioslinks.inc',bioslinks)
 config=config.replace('        INCLUDE cpxlinks.inc',
                       equ(es,('EX_RETURN','BCX_MVAL')))
 config=config.replace('ZP_PHYSICAL EQU 0FFFFH',
                       f"ZP_PHYSICAL EQU 0{ds['Z_PHYSICAL']:04X}H")
 tail=read('src/bios/config.mac').split('CPTCOUNT EQU',1)[1].split('CF_GETPH:',1)[0]
 config+='CPTCOUNT EQU'+tail+'\n        END\n'
 ctl=asm('config',config,L['CONFIG'],1024)
 tables='        INCLUDE layout.inc\n        ASEG\n        ORG LY_TAB\n'
 for i in range(4):
  binding=fmt.binding(i)
  tables+=f'ZDPH{i}: DW 0,0,0,0,LY_DIR,ZDPH{i}+17,ZCSV+{i * 32},ZALV\n'
  # z80asm accepts a long DB line but silently drops operands beyond its
  # internal line capacity.  Keep each directive short and verify stride.
  for offset in range(0,len(binding),16):
   tables+='        DB '+','.join(str(value) for value in binding[offset:offset+16])+'\n'
 # CONFIG may replace the boot binding with any supported catalogue format.
 # Keep one maximum-size allocation vector for the active BDOS context and a
 # persistent 32-byte checksum vector for each logical drive.  Sizing these
 # workspaces from the boot format corrupts the following drive's checksum
 # state as soon as a larger disk is selected.
 tables+='ZALV: DS 128\nZCSV: DS 128\n'
 tables+='        END\n'
 tab=asm('tables',tables,L['TABLES'],L['RSX_STATE']-L['TABLES'])
 gateway=asm('gateway',read('src/system/gateway.mac').replace('        INCLUDE core.inc',core),L['SYSTEM'],L['BDOS']-L['SYSTEM'])
 if args.resident_only:
  return
 if not args.ram_only:
  subprocess.run([sys.executable,str(ROOT/'tools/test_rom_ownership_inventory.py'),
                  '--platform','z80pack','--listing-root',str(out)],check=True)
  subprocess.run([sys.executable,str(ROOT/'tools/test_rom_profile_ram_map.py')],check=True)
  rom=out/'rom'
  subprocess.run([sys.executable,str(ROOT/'tools/build_rom_ram_template.py'),
                  '--z80pack-build',str(out),'--output',str(rom)],check=True)
  subprocess.run([sys.executable,str(ROOT/'tools/test_rom_ram_template.py'),
                  '--z80pack-build',str(out),'--template',str(rom)],check=True)
  subprocess.run([sys.executable,str(ROOT/'tools/build_rom_cold_init.py'),
                  '--assembler',str(args.assembler),'--template',str(rom),
                  '--output',str(rom)],check=True)
  subprocess.run([sys.executable,str(ROOT/'tools/test_rom_cold_init.py'),
                  '--template',str(rom),'--initializer',str(rom)],check=True)
  subprocess.run([sys.executable,str(ROOT/'tools/build_rom_pack.py'),
                  '--z80pack-build',str(out),'--artifacts',str(rom),
                  '--output',str(rom)],check=True)
  subprocess.run([sys.executable,str(ROOT/'tools/test_rom_pack.py'),
                  '--z80pack-build',str(out),'--artifacts',str(rom),
                  '--pack',str(rom)],check=True)
  subprocess.run([sys.executable,str(ROOT/'tools/build_rom_reference_inventory.py'),
                  '--z80pack-build',str(out),'--pack',str(rom),
                  '--output',str(rom/'rom-references.json')],check=True)
  subprocess.run([sys.executable,str(ROOT/'tools/test_rom_reference_inventory.py'),
                  '--z80pack-build',str(out),'--pack',str(rom),
                  '--inventory',str(rom/'rom-references.json')],check=True)
  subprocess.run([sys.executable,str(ROOT/'tools/build_rom_relocated_image.py'),
                  '--pack',str(rom),'--inventory',str(rom/'rom-references.json'),
                  '--output',str(rom)],check=True)
  subprocess.run([sys.executable,str(ROOT/'tools/test_rom_relocated_image.py'),
                  '--pack',str(rom),'--inventory',str(rom/'rom-references.json'),
                  '--image',str(rom)],check=True)
 reload=z80pack_reloader_source(read('src/platform/trs80m4/ccprelod.mac'))
 loader=asm('reloader',reload,L['RELOADER'],L['RELOADER_CAPACITY'])
 if not args.ram_only:
  build_rom_boot(out,rom,args.assembler.expanduser().resolve(),
                 fmt.raw_tracks,fmt.raw_track_bytes//128)
 selector=asm('rsxselect',read('src/platform/z80pack/rsxsel.mac'),L['RSX_SELECTOR'],1024-L['RELOADER_CAPACITY'])
 if not args.ram_only:
  rom_overlays=rom/'rsx-overlays'
  build_rom_rsx_overlays(rom,rom_overlays,out/'rsxselect.bin',
                         args.assembler.expanduser().resolve())
 bootfmt=(f'ZB_TRACKS EQU {fmt.raw_tracks}\n'
          f'ZB_SLOTS EQU {fmt.raw_track_bytes//128}\n')
 boot_source=read('src/platform/z80pack/boot.mac').replace('        INCLUDE bootfmt.inc',bootfmt)
 boot_source=boot_source.replace('        DB ZB_MAP_BYTES',
                                 '        DB '+','.join(map(str,record_map)))
 boot=asm('boot',boot_source,0,128)
 resident=bytearray(L['DIRBUF']-L['SYSTEM'])
 parts=[(L['SYSTEM'],gateway),(L['BDOS'],(ROOT/'build/bdos/bdos.bin').read_bytes()),(L['EXTENSIONS'],ext),(L['DISK'],disk),(L['BIOS'],bios),(L['FILE'],(ROOT/'build/system/fileloader.bin').read_bytes()),(L['TABLES'],tab)]
 for address,data in parts:resident[address-L['SYSTEM']:address-L['SYSTEM']+len(data)]=data
 if len(resident)>52*128:raise ValueError('resident carrier too small')
 logical=bytearray(b'\xe5'*fmt.image_bytes)
 def put(record,data,capacity):
  if len(data)>capacity:raise ValueError('carrier overflow')
  logical[record*128:record*128+capacity]=data.ljust(capacity,b'\0')
 loader_carrier=loader.ljust(L['RELOADER_CAPACITY'],b'\0')+selector.ljust(1024-L['RELOADER_CAPACITY'],b'\0')
 from startup_record import build as startup_record
 put(0,boot,128);put(1,startup_record(system_base=L['SYSTEM']),256)
 put(8,resident,52*128);put(60,loader_carrier,1024);put(68,ctl,1024)
 gateway_tail=bytes((0xc3,L['BDOS']&255,L['BDOS']>>8))
 def rsx_overlay(path):return path.read_bytes().ljust(1021,b'\0')+gateway_tail
 put(76,rsx_overlay(ROOT/'build/system/rsxloader.bin'),1024)
 put(84,bytes(1021)+gateway_tail,1024)
 put(92,bytes(1021)+gateway_tail,1024)
 put(100,rsx_overlay(ROOT/'build/system/rsxresolver.bin'),1024)
 put(108,(ROOT/'build/ccp/ccp.rlm').read_bytes(),13*512)
 (out/'resident.bin').write_bytes(resident)
 if not args.resident_only:
  subprocess.run([sys.executable,str(ROOT/'tools/build_disk_utilities.py'),
                  '--config-extra-resident',str(out/'resident.bin'),
                  '--config-extra-spt',str(fmt.spt)],check=True,stdout=subprocess.DEVNULL)
 if args.system_tracks_only:
  # The distribution builder supplies its own filesystem from its manifest.
  # Do not first pack the unrelated, larger development/test file inventory.
  raw=bytearray(b'\xe5'*fmt.image_bytes)
  for record in range(fmt.reserved_records):
   track,within=divmod(record,fmt.spt)
   at=track*fmt.raw_track_bytes+record_map[within]*128
   raw[at:at+128]=logical[record*128:(record+1)*128]
  disks.mkdir()
  for letter in 'abcd':(disks/f'drive{letter}.dsk').write_bytes(raw)
  (out/'diskdefs').write_text(disk_definition(fmt))
  return
 # CP/M 2.2, 1K allocation blocks, byte block numbers, 64 directory entries.
 files=[]
 for name in ('RCP.CPX','HELLO.CPX'):files.append((name,(ROOT/'build/cpx'/name).read_bytes()))
 # The small development disk keeps its existing test inventory. ED is
 # installed by its isolated campaigns and the manifest-driven System Disk.
 # Model 4-only monitor tests likewise do not belong on this disk.
 for f in sorted((ROOT/'build/utilities').glob('*.COM')):
  if f.name not in ('ADMTST.COM','VT52TST.COM','ANSITST.COM','ED.COM'):files.append((f.name,f.read_bytes()))
 for name,data in cpm_tools_files(ROOT):files.append((name,data))
 for name in ('HELLO.RSX','ECHO.RSX','BATCHIO.RSX','FDF.RSX','P2DOS.RSX','ZPRTC.RSX','STATEFUL.RSX'):files.append((name,(ROOT/'build/rsx'/name).read_bytes()))
 files.append(('R3PACK.RSX',(ROOT/'build/system/R3PACK.RSX').read_bytes()))
 for name in ('R3PLAN.RSX','R3SLOTS.RSX','R3SNAP.RSX','R3CARR.RSX','R3META.RSX','R3COORD.RSX','R3PROF.RSX','R3KCTX.RSX','R3KEEP.RSX','R3KPRE.RSX','R3FINAL.RSX','R3DROP.RSX','R3MOVE.RSX','R3COMIT.RSX','R3RESOL.RSX'):files.append((name,(ROOT/'build/system'/name).read_bytes()))
 files.append(('DISK.FDB',build_fdf_catalog().read_bytes()))
 # A small transient proves that load and warm return use this target BIOS.
 hello=bytes([0x11,0x0b,1,0x0e,9,0xcd,5,0,0xc3,0,0])+b'BetterCP/M on z80pack\r\n$'
 files.append(('HELLO.COM',hello))
 # cpmsim hardware control: unlock, then halt the emulator cleanly.
 files.append(('BYE.COM',bytes((0x3e,0xaa,0xd3,160,0x3e,0x80,0xd3,160,0x76))))
 start=fmt.reserved_records*128;block=fmt.directory_blocks;entry=0
 for name,data in files:
  stem,suffix=name.split('.');payload=data.ljust((len(data)+127)//128*128,b'\x1a')
  for chunkstart in range(0,max(len(payload),1),16384):
   chunk=payload[chunkstart:chunkstart+16384];count=(len(chunk)+fmt.block_bytes-1)//fmt.block_bytes
   if entry>fmt.drm or block+count>fmt.dsm+1:raise ValueError('filesystem full')
   e=bytearray(32);e[1:9]=stem.ljust(8).encode();e[9:12]=suffix.ljust(3).encode()
   extent=chunkstart//16384;e[12]=extent&31;e[14]=extent>>5;e[15]=len(chunk)//128
   if fmt.dsm<256:e[16:16+count]=bytes(range(block,block+count))
   else:
    for slot,value in enumerate(range(block,block+count)):
     struct.pack_into('<H',e,16+slot*2,value)
   logical[start+entry*32:start+(entry+1)*32]=e
   logical[start+block*fmt.block_bytes:start+block*fmt.block_bytes+len(chunk)]=chunk
   entry+=1;block+=count

 def raw_image(flat):
  raw=bytearray(b'\xe5'*fmt.image_bytes)
  for track in range(fmt.raw_tracks):
   logical_base=track*fmt.spt*128
   raw_base=track*fmt.raw_track_bytes
   for record,slot in enumerate(record_map):
    source=logical_base+record*128;destination=raw_base+slot*128
    raw[destination:destination+128]=flat[source:source+128]
  return bytes(raw)

 raw=raw_image(logical)
 rom_logical=bytearray(logical)
 rom_loader=(rom/'rom-reloader.bin').read_bytes()
 rom_selector=(rom_overlays/'RSXSEL.BIN').read_bytes()
 rom_loader_carrier=rom_loader.ljust(L['RELOADER_CAPACITY'],b'\0')+rom_selector.ljust(1024-L['RELOADER_CAPACITY'],b'\0')
 rom_logical[60*128:68*128]=rom_loader_carrier
 rom_ccp=(rom/'rom-ccp.rlm').read_bytes()
 rom_logical[108*128:160*128]=rom_ccp.ljust(13*512,b'\0')
 def replace_rom_file(name,data):
  stem,suffix=name.split('.')
  wanted=stem.ljust(8).encode()+suffix.ljust(3).encode()
  directory=fmt.reserved_records*128
  for index in range(fmt.drm+1):
   entry=directory+index*32
   if bytes(rom_logical[entry+1:entry+12])!=wanted:continue
   records=rom_logical[entry+15]
   if records*128<len(data):raise ValueError(f'{name}: ROM replacement exceeds directory extent')
   blocks=[]
   if fmt.dsm<256:blocks=[value for value in rom_logical[entry+16:entry+32] if value]
   else:
    blocks=[struct.unpack_from('<H',rom_logical,entry+16+slot*2)[0] for slot in range(8)]
    blocks=[value for value in blocks if value]
   payload=data.ljust(records*128,b'\x1a');cursor=0
   for value in blocks:
    count=min(fmt.block_bytes,len(payload)-cursor)
    if count<=0:break
    start=fmt.reserved_records*128+value*fmt.block_bytes
    rom_logical[start:start+count]=payload[cursor:cursor+count];cursor+=count
   if cursor!=len(payload):raise ValueError(f'{name}: incomplete ROM replacement')
   return
  raise ValueError(f'{name}: missing from ROM filesystem')
 rom_entries=json.loads((rom/'rom-image.json').read_text())['entries']
 rom_gateway_tail=bytes((0xc3,rom_entries['bdos']&255,rom_entries['bdos']>>8))
 rom_config=bytearray(ctl)
 reference_manifest=json.loads((rom/'rom-references.json').read_text())
 overlay_references=reference_manifest['overlay_references']
 for reference in overlay_references:
  offset=reference['overlay_operand']
  old=int.from_bytes(rom_config[offset:offset+2],'little')
  if old!=reference['old_target']:
   raise ValueError(f'CONFIG relocation source changed at {offset:04X}h')
  rom_config[offset:offset+2]=reference['new_target'].to_bytes(2,'little')
 rom_config=bytes(rom_config)
 (rom/'rom-config.bin').write_bytes(rom_config)
 (rom/'rom-config.json').write_text(json.dumps({
  'bytes':len(rom_config),'relocation_words':len(overlay_references),
  'references':overlay_references,
  'source_sha256':hashlib.sha256(ctl).hexdigest(),
  'sha256':hashlib.sha256(rom_config).hexdigest(),
 },indent=2,sort_keys=True)+'\n')
 rom_logical[68*128:76*128]=rom_config.ljust(1024,b'\0')
 rom_logical[76*128:84*128]=(rom_overlays/'RSXLOAD.BIN').read_bytes().ljust(1021,b'\0')+rom_gateway_tail
 rom_logical[100*128:108*128]=(rom_overlays/'RSXRESOL.BIN').read_bytes().ljust(1021,b'\0')+rom_gateway_tail
 for name in sorted(('R3PLAN.RSX','R3SLOTS.RSX','R3SNAP.RSX','R3CARR.RSX','R3META.RSX','R3COORD.RSX','R3PROF.RSX','R3KCTX.RSX','R3KEEP.RSX','R3KPRE.RSX','R3FINAL.RSX','R3DROP.RSX','R3MOVE.RSX','R3COMIT.RSX','R3RESOL.RSX')):
  replace_rom_file(name,(rom_overlays/name).read_bytes())
 replace_rom_file('R3PACK.RSX',(rom_overlays/'R3PACK.RSX').read_bytes())
 rom_raw=raw_image(rom_logical)
 blank=raw_image(bytearray(b'\xe5'*fmt.image_bytes))
 disks.mkdir();library=disks/'library';library.mkdir()
 media={
  'a':('BetterCPM-System-CCS-40T-DS-DD-332K.dsk',raw),
  'b':('Blank-B-CCS-40T-DS-DD-332K.dsk',blank),
  'c':('Blank-C-CCS-40T-DS-DD-332K.dsk',blank),
  'd':('Blank-D-CCS-40T-DS-DD-332K.dsk',blank),
 }
 for letter,(name,data) in media.items():
  (library/name).write_bytes(data)
  (disks/f'drive{letter}.dsk').symlink_to(Path('library')/name)
 rom_name='BetterCPM-ROM-System-CCS-40T-DS-DD-332K.dsk'
 (library/rom_name).write_bytes(rom_raw)
 rom_disks=out/'rom-disks';rom_disks.mkdir()
 (rom_disks/'drivea.dsk').symlink_to(Path('../disks/library')/rom_name)
 for letter in ('b','c','d'):
  (rom_disks/f'drive{letter}.dsk').symlink_to(
      Path('../disks')/f'drive{letter}.dsk')
 (out/'diskdefs').write_text(disk_definition(fmt))
 simulator=args.simulator.expanduser().resolve()
 if not simulator.is_file():raise SystemExit(f'missing cpmsim simulator: {simulator}')
 (out/'launch-z80pack.command').write_text('#!/bin/sh\ncd -- "$(dirname -- "$0")" || exit 1\nPATH="'+str(simulator.parent/'srctools')+':$PATH"\nexport PATH\nexec "'+str(simulator)+'" -z -d "$PWD/disks" "$@"\n')
 (out/'launch-z80pack.command').chmod(0o755)
 (out/'launch-z80pack-rom.command').write_text('#!/bin/sh\ncd -- "$(dirname -- "$0")" || exit 1\nPATH="'+str(simulator.parent/'srctools')+':$PATH"\nexport PATH\nexec "'+str(simulator)+'" -z -x "$PWD/rom/rom-boot.hex" -d "$PWD/rom-disks" "$@"\n')
 (out/'launch-z80pack-rom.command').chmod(0o755)
 (out/'manifest.json').write_text(json.dumps({'target':'z80pack/cpmsim','format':fmt.name,'cylinders':fmt.cylinders,'sides':fmt.sides,'physical_sectors_per_track':fmt.physical_sectors,'physical_sector_bytes':fmt.sector_bytes,'image_bytes':fmt.image_bytes,'records_per_logical_track':fmt.spt,'reserved_tracks':fmt.off,'reserved_records':fmt.reserved_records,'allocation_kib':(fmt.dsm+1)*fmt.block_bytes//1024,'cpmtools_format':'bettercpm-default','sha256':hashlib.sha256(raw).hexdigest(),'shared_bdos_sha256':hashlib.sha256((ROOT/'build/bdos/bdos.bin').read_bytes()).hexdigest()},indent=2)+'\n')
 print(f'Created linked media in {library}; {fmt.name}; {(fmt.dsm+1)*fmt.block_bytes//1024} KiB allocation area')
if __name__=='__main__':main()
