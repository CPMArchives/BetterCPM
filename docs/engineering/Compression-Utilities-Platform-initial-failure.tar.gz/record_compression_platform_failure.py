from pathlib import Path
import sys,json,hashlib,tarfile,gzip,io
r=Path('/private/tmp/bettercpm-sq-command-20261023');sys.path.insert(0,str(r/'tools'))
import test_codec_utilities_platforms as h
base=Path('/private/tmp/compression-query-platform-parallel');system=Path('/private/tmp/query-standard-system/release-c18ff9c2f79f-d2f01f863bfe');eng=r/'docs/engineering';sha=h.sha
report=json.loads((base/'report.json').read_text());report['compression_utilities_acceptance']='FAIL';report['whole_utilities_disk']='PROVISIONAL';report['platforms']['trs80gp']={'status':'FAIL','families':{}}
entries={'test_codec_utilities_platforms.py':(r/'tools/test_codec_utilities_platforms.py').read_bytes()}
for platform in ['z80pack','trs80gp']:
 for family in ['SQ','CR','LZH']:
  w=base/platform/family
  if (w/'result.json').exists():
   trial=json.loads((w/'result.json').read_text())
   assert sha((w/'a.raw').read_bytes())==trial['output_a_sha256']
   assert sha((w/'c.raw').read_bytes())==trial['output_c_sha256']
   assert sha((w/'b.raw').read_bytes())==trial['private_input_sha256']['b']
  else:
   assert platform=='trs80gp' and family=='SQ'
   fmt=h.select_fdf(r/'third_party/montezuma/DISK-INT.FDF','Montezuma Micro 80T DS DATA (80T, DS, DD, 800K)')
   src=next(p for p in (system/platform).glob('*.dmk') if 'boot-test' not in p.name)
   import tempfile
   probe=Path(tempfile.mkdtemp(prefix='sq-failed-case-audit-'))/'seed'
   a,b,c,adef,definition,originals,sentinels=h.prepare(probe,platform,family,src,base/'packaged/BetterCPM-Utilities-trs80gp-80T-DS-800K.dmk',fmt)
   assert (w/'b.raw').read_bytes()==b.read_bytes()
   rows=h.steps(family,platform);caps=sorted(w.glob('trs80-text-*.bin'),key=lambda p:int(p.stem.rsplit('-',1)[1]));assert len(caps)==len(rows)+1
   screens=[]
   for row,cap in zip(rows,caps[1:]):
    raw=bytes(x&127 for x in cap.read_bytes()[:1920]);text='\n'.join(raw[i:i+80].decode().rstrip() for i in range(0,1920,80))
    assert '\n'.join(row['expected'].splitlines()) in text,(row,text)
    assert text.rstrip().endswith((row['prompt'],row['prompt']+'_'))
    screens.append({'command':row['command'],'capture':cap.name,'sha256':sha(cap.read_bytes())})
   actual={name:h.get(w,w/'c.raw',definition,0,name) for name in sentinels}
   failures={name:{'expected_sha256':sha(data),'actual_sha256':sha(actual[name]),'bytes':len(actual[name]),'actual_all_e5':set(actual[name])=={229}} for name,data in sentinels.items() if actual[name]!=data}
   assert set(failures)==set(sentinels)
   for (user,name),value in originals.items():assert h.get(w,w/'a.raw',adef,user,name)==value,(user,name,'source changed')
   for name,value in h.fixtures():
    assert h.get(w,w/'c.raw',definition,0,name)==h.padded(value),name
    assert h.decode_sq(h.get(w,w/'c.raw',definition,0,h.compressed_name(family,name)))[1]==h.padded(value),name
   other_failures={}
   checks=[('c.raw',definition,0,'DEFAULT.TXT',h.padded(b'logged drive defaults')),('a.raw',adef,0,'DEFAULT.TXT',h.padded(b'logged drive defaults')),('c.raw',definition,7,'USER.TXT',originals[(7,'USER.TXT')]),('c.raw',definition,0,'SAVED.BIN',h.padded(dict(h.fixtures())['BIG.BIN']))]
   for image,df,user,name,expected in checks:
    value=h.get(w,w/image,df,user,name)
    if value!=expected:other_failures[image+':'+str(user)+':'+name]={'expected_sha256':sha(expected),'actual_sha256':sha(value),'actual_all_e5':set(value)=={229}}
   for image,df in [('a.raw',adef),('b.raw',definition),('c.raw',definition)]:h.command(w,'fsck.cpm','-n','-f',df,w/image)
   trial={'commands':rows,'regular_round_trips':7,'preexisting_temporaries_preserved':False,'other_file_failures':other_failures,'filesystem':'PASS'}
   trial.update({'status':'FAIL','failure':'preexisting temporary payload corruption','sentinel_failures':failures,'evidence':{'screens':screens},'private_input_sha256':{k:sha(p.read_bytes()) for k,p in zip('abc',(a,b,c))},'output_a_sha256':sha((w/'a.raw').read_bytes()),'output_c_sha256':sha((w/'c.raw').read_bytes())})
  src=next(p for p in (system/platform).iterdir() if p.suffix in ['.dsk','.dmk'] and 'boot-test' not in p.name)
  trial['system_payload_readback']=h.verify_system_payloads(w,w/'a.raw',h.FORMATS[platform] if platform=='z80pack' else 'codec-system',src,platform)
  trial['source_system_sha256']=sha(src.read_bytes())
  if platform=='trs80gp':report['platforms'][platform]['families'][family]=trial
  for p in w.iterdir():
   if p.suffix in ['.json','.txt','.bin'] and p.name not in ['import.bin','export.bin']:entries[f'{platform}/{family}/{p.name}']=p.read_bytes()
 for p in (system/platform).iterdir():
  if p.suffix in ['.json','.txt']:entries[f'system/{platform}/{p.name}']=p.read_bytes()
for p in (base/'source-snapshots').glob('*.py'):
 assert p.stem==sha(p.read_bytes());entries['source-snapshots/'+p.name]=p.read_bytes()
for name in ['compression-query-platform-resumed.log','compression-platform-environment.json','compression-platform-receipt-guards.json','record_compression_platform_failure.py']:
 entries[name]=Path('/private/tmp',name).read_bytes()
report['audit_source_sha256']=sha(Path(__file__).read_bytes());report['limits']=['Model 4 SQ sentinel corruption blocks platform acceptance; cause not established','clean pinned cpmsim reconstruction remains open','native ZSM4 codec assembly remains open','whole Utilities inventory and final-image acceptance remain open']
data=(json.dumps(report,indent=2)+'\n').encode();entries['report.json']=data
(eng/'Compression-Utilities-Platform-evidence.json').write_bytes(data)
buf=io.BytesIO()
with gzip.GzipFile(fileobj=buf,mode='wb',filename='',mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w') as tar:
  for name,data in sorted(entries.items()):
   t=tarfile.TarInfo(name);t.size=len(data);t.mode=0o644;tar.addfile(t,io.BytesIO(data))
(eng/'Compression-Utilities-Platform-evidence.tar.gz').write_bytes(buf.getvalue())
print('Recorded Model 4 SQ data-integrity FAIL; see detailed file failures.')
