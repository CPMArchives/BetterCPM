from pathlib import Path
import sys,shutil,subprocess,json,hashlib
sys.path.insert(0,str(Path.cwd()/'tools'))
from add_cpm_file_to_dmk import extract_raw
sha=lambda b:hashlib.sha256(b).hexdigest()
old=Path('/private/tmp/ted-v3-session-trs80gp')
out=Path('/private/tmp/ted-v3-native-trs80gp');shutil.copytree(old,out,dirs_exist_ok=True)
p=out/'trs80gp';raw=p/'native-snapshot.raw';raw.write_bytes(extract_raw((p/'a.dmk').read_bytes()))
def tool(*args):return subprocess.run(list(map(str,args)),cwd=p,check=True,capture_output=True)
for n in ('TEDDEV.COM','TEDNAT.MAC','IGRP.TXT','INSERT.TXT','WRITE.TXT','TEB00000.BAK'):
 tool('cpmcp','-T','raw','-f','dasm-system',raw,'0:'+n,p/('after-'+n))
binary=(Path.cwd()/'build/utilities/TED.COM').read_bytes();native=(p/'after-TEDDEV.COM').read_bytes()
assert native[:len(binary)]==binary
assert len(native) in (len(binary),(len(binary)+127)//128*128)
assert set(native[len(binary):])<={0,26}
assert (p/'after-TEB00000.BAK').read_bytes()==b'read line\n'+b'\x1a'*118
source=(p/'TEDNAT.MAC').read_bytes();actual=(p/'after-TEDNAT.MAC').read_bytes()
assert actual[:len(source)]==source and set(actual[len(source):])<={0,26}
for n,data in [('IGRP.TXT',b'one\r\ntwo\r\nthree\r\nfour\r\n'),('INSERT.TXT',b'one\r\ntwo\r\nthree\r\nfour\r\n'),('WRITE.TXT',b'read line\n')]:
 assert (p/('after-'+n)).read_bytes()==data+b'\x1a'*((-len(data))%128),n
screens=[x.read_bytes() for x in sorted(p.glob('trs80-text-*'),key=lambda x:int(x.stem.rsplit('-',1)[1]))]
log=b'\n'.join(bytes(v&127 for v in b[:1920]) for b in screens)
assert b'Errors: 0' in log and b'76AC (0100-77AB)' in log
assert b'TED STACK HIGH WATER 00054 TPA CEILING 50689 TED GROUPS PASS' in log
assert b'TED GUARD FAIL' not in log
(p/'console.bin').write_bytes(log)
check=subprocess.run(['fsck.cpm','-T','raw','-f','dasm-system','-n',str(raw)],cwd=p,capture_output=True)
assert check.returncode==2 and b'$$$     .SUB' in check.stdout+check.stderr, 'unexpected snapshot filesystem result'
(p/'filesystem.txt').write_bytes(check.stdout+check.stderr)
sp=out/'paired-media/System.dmk';up=out/'paired-media/BetterCPM-Utilities-trs80gp-80T-DS-800K.dmk'
frozen=Path('/private/tmp/dasm-fresh-systems/release-370060c2c289-8856bd3f4c44/trs80gp');sr=json.loads((frozen/'report.json').read_text())
assert sp.read_bytes()==(frozen/sr['image']).read_bytes()
assert up.read_bytes()==(p/'b.dmk').read_bytes()==(Path.cwd()/'build/ted-final-utilities-v3'/up.name).read_bytes()
e={'platform':'trs80gp','scope':'native build/parity and completed block/file workflow only; subsequent installed interaction campaign stopped on harness readiness','system_sha256':sha(sp.read_bytes()),'utilities_sha256':sha(up.read_bytes()),'native_source_sha256':sha(source),'native_file_sha256':sha(native),'emulator_sha256':sha(Path('/Users/nathanael/trs80/trs80gp-2/mac/trs80gp.app/Contents/MacOS/trs80gp').read_bytes()),'original_media_unchanged':True,'filesystem_snapshot':'NOT_ACCEPTED: stopped while SUBMIT active; retained checker diagnoses active $$$.SUB; final installed session must close and pass independently','commands':['B:ZSM4 TEDDEV=TEDNAT','B:LINK TEDDEV[A]'],'outputs':{n:sha((p/('after-'+n)).read_bytes()) for n in ('TEDDEV.COM','TEDNAT.MAC','IGRP.TXT','INSERT.TXT','WRITE.TXT')}}
(p/'execution.json').write_text(json.dumps(e,indent=2)+'\n')
r={'status':'PASS','scope':e['scope'],'installed':False,'payload_sha256':sha(binary),'platforms':{'trs80gp':{'status':'PASS','native_build':True,'native_cross_parity':True,'groups_outputs_verified':True,'scenarios':{'GROUPS':{'stack_high_water':54,'tpa_ceiling':50689}},'stack_high_water':54,'tpa_ceiling':50689,'execution':'trs80gp/execution.json'}}}
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
(out/'retain-native-proof.py').write_bytes(Path(__file__).read_bytes())
print('PASS: native Model 4 parity, padding, source readback, completed group outputs and memory guards; later interaction not accepted')
