NOAH revision 7 codec/production-overlay qualification, 2026-10-25.
full/: complete native ZSM4/LINK and runtime campaign before timestamp-warning fix.
final/: bounded final delta; boot/controller rebuilt on both platforms, unchanged
codec products reused after exact parity checks. Includes stamped extraction.
report.json in each directory records product hashes and exact memory layout.
Native six-module sources and products are under cross/ and platform build dirs.
Disk images and assembler listings are excluded; invocation/execution receipts,
console output, filesystem results and extracted products are retained.
source/: changed implementation/build/test inputs; self-contained generated native
sources in final/cross/ also retain unchanged dependencies needed for assembly.
host/: scoped assembled-code test results. No whole Utilities acceptance claimed.
