NOAH revision 8 quiet reporting qualification, 2026-10-25.
native/: both-platform native boot/controller builds and quiet runtime campaign.
Unchanged codec products were parity checked before reuse from revision 7;
reused/: exact retained native codec outputs and their original build receipts.
host/: focused quiet-output and existing regression suite results.
source/: changed implementation, build, metadata and test inputs.
Native cross/ contains the self-contained six-module assembly sources.
Disk images and large assembler listings are omitted; execution/invocation,
console/fsck results and extracted outputs are retained. No full NOAH or Utilities
release claim. The known all-failed new ADD issue is recorded in the engineering note.
