NOAH LINK investigation, 2026-10-25. Current native controller/modules and
complete current-runtime receipts are BetterCP/M proof artifacts. The old-image
and stock-CP/M traces used a test-only BDOS interceptor at C000h, lowering the
active ceiling; no instrumented third-party executable is distributed here.
trace.mac assembles at C000h: combine its raw bytes with unchanged LINK.COM at
0100h, pad to C000h, replace only the test image's entry jump with JP C003h.
The pinned LINK entry called by the wrapper is 01A7h. Its BDOS chain preserves
original calls and logs file open/create/close/read failure. The stock tracer
omits close logging; both sources are retained. Uninstrumented old-image runs
with and without [A] independently reproduce the failure. Current successful
native qualification uses original unmodified ZSM4/LINK and the unchanged proof.
No OS images, third-party tools or new NOAH functionality are in this bundle.
